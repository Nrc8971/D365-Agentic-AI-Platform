"""
╔═══════════════════════════════════════════════════════════════════╗
║        FDD → X++ Code Generation Platform                        ║
║        Streamlit Frontend · Anthropic Claude Backend             ║
╚═══════════════════════════════════════════════════════════════════╝
"""

import streamlit as st
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

from ui.layout import render_header, render_sidebar, inject_custom_css
from ui.pages.upload_page import render_upload_page
from ui.pages.analysis_page import render_analysis_page
from ui.pages.design_page import render_design_page
from ui.pages.codegen_page import render_codegen_page
from ui.pages.review_page import render_review_page

# ──────────────────────────────────────────────
# PAGE CONFIG
# ──────────────────────────────────────────────
st.set_page_config(
    page_title="FDD → X++ Platform",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

inject_custom_css()

# ──────────────────────────────────────────────
# SESSION STATE INIT
# ──────────────────────────────────────────────
defaults = {
    "current_page": "upload",
    "fdd_raw_text": None,
    "fdd_filename": None,
    "fdd_metadata": {},
    "requirements": None,
    "technical_design": None,
    "xpp_code": None,
    "validation_report": None,
    "pipeline_stage": 0,   # 0=idle 1=req 2=design 3=code 4=done
    # ── API / Provider ──────────────────────────────
    "api_key": "",          # Anthropic key
    "google_api_key": "",   # Google Gemini key
    "ai_provider": "anthropic",  # "anthropic" | "google"
    # ── Project ─────────────────────────────────────
    "project_name": "",
    "model_prefix": "PROJ_",
    "d365_module": "General",
    "processing": False,
    "errors": [],
    "stage_timings": {},
}
for k, v in defaults.items():
    if k not in st.session_state:
        st.session_state[k] = v

# ──────────────────────────────────────────────
# LAYOUT
# ──────────────────────────────────────────────
render_header()
render_sidebar()

# ──────────────────────────────────────────────
# PAGE ROUTING
# ──────────────────────────────────────────────
page = st.session_state.current_page

if page == "upload":
    render_upload_page()
elif page == "analysis":
    render_analysis_page()
elif page == "design":
    render_design_page()
elif page == "codegen":
    render_codegen_page()
elif page == "review":
    render_review_page()
