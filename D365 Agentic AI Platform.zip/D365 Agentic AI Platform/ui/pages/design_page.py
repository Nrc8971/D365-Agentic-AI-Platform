import streamlit as st
import time
from ui.layout import render_pipeline_progress
from ai_engine.design_generator import DesignGenerator


def render_design_page():
    render_pipeline_progress()

    st.markdown('<div class="section-title">🏗️ Technical Design Document</div>', unsafe_allow_html=True)
    st.markdown('<div class="section-subtitle">AI generates a complete Technical Design Document — architecture, data model, extension strategy, and class design.</div>', unsafe_allow_html=True)

    if not st.session_state.requirements:
        st.warning("⚠️ Run Requirements Analysis first.")
        if st.button("← Back to Analysis"):
            st.session_state.current_page = "analysis"
            st.rerun()
        return

    if not st.session_state.technical_design:
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            st.markdown("""
            <div class="glass-card" style="text-align:center; padding:2.5rem;">
                <div style="font-size:3rem; margin-bottom:1rem;">🏗️</div>
                <div style="font-size:1.1rem; font-weight:600; color:#e2e2f0; margin-bottom:0.5rem;">Ready to Design</div>
                <div style="font-size:0.82rem; color:#6b7280; margin-bottom:1.5rem;">
                    Claude will produce a full Technical Design Document covering 
                    solution architecture, X++ class design, data model, and extension strategy.
                </div>
            </div>
            """, unsafe_allow_html=True)
            if st.button("🏗️ Generate Technical Design", use_container_width=True):
                _run_design()
    else:
        _display_design()
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            if st.button("⚙️ Proceed to Code Generation →", use_container_width=True):
                st.session_state.current_page = "codegen"
                st.rerun()
        with col1:
            if st.button("🔄 Regenerate", use_container_width=True):
                st.session_state.technical_design = None
                st.rerun()


def _get_active_key_and_provider():
    provider = st.session_state.get("ai_provider", "anthropic")
    if provider == "google":
        return st.session_state.get("google_api_key", ""), "google"
    return st.session_state.get("api_key", ""), "anthropic"


def _run_design():
    key, provider = _get_active_key_and_provider()
    gen = DesignGenerator(api_key=key, provider=provider)
    context = {
        "project_name": st.session_state.project_name,
        "model_prefix": st.session_state.model_prefix,
        "d365_module": st.session_state.d365_module,
    }

    progress = st.progress(0, text="Initializing design generator...")
    status = st.empty()

    stages = [
        (20, "📐 Designing solution architecture..."),
        (40, "🗃 Designing data model..."),
        (60, "🧩 Designing X++ class structure..."),
        (80, "📝 Writing Technical Design Document..."),
        (100, "✅ Technical design complete!"),
    ]

    try:
        for pct, msg in stages[:-1]:
            progress.progress(pct / 100, text=msg)
            status.markdown(f"<div style='font-size:0.82rem;color:#60a5fa'>{msg}</div>", unsafe_allow_html=True)
            time.sleep(0.3)

        result = gen.generate(
            st.session_state.fdd_raw_text,
            st.session_state.requirements,
            context
        )
        st.session_state.technical_design = result
        st.session_state.pipeline_stage = 3

        progress.progress(1.0, text="✅ Done!")
        status.empty()
        st.rerun()

    except Exception as e:
        progress.empty()
        status.empty()
        st.error(f"Design generation failed: {str(e)}")


def _display_design():
    td = st.session_state.technical_design

    tabs = st.tabs(["📋 Overview", "🗃 Data Model", "🧩 Class Design",
                    "🔀 Flow Diagrams", "📄 Full TDD", "⬇ Export"])

    with tabs[0]:
        col1, col2 = st.columns(2)
        with col1:
            st.markdown('<div class="glass-card">', unsafe_allow_html=True)
            st.markdown('<div class="card-title">🏛 Solution Architecture</div>', unsafe_allow_html=True)
            st.markdown(td.get("architecture_overview", "N/A"))
            st.markdown('</div>', unsafe_allow_html=True)

            st.markdown('<div class="glass-card">', unsafe_allow_html=True)
            st.markdown('<div class="card-title">🎯 Design Decisions</div>', unsafe_allow_html=True)
            for dd in td.get("design_decisions", []):
                st.markdown(f"**{dd.get('decision','?')}**")
                st.markdown(f"*Rationale:* {dd.get('rationale','')}")
                st.markdown("---")
            st.markdown('</div>', unsafe_allow_html=True)

        with col2:
            st.markdown('<div class="glass-card">', unsafe_allow_html=True)
            st.markdown('<div class="card-title">📦 Solution Components</div>', unsafe_allow_html=True)
            for comp in td.get("components", []):
                badge_type = {"Service": "badge-purple", "Table": "badge-blue",
                              "Form": "badge-green", "Enum": "badge-amber"}.get(comp.get("type",""), "badge-blue")
                st.markdown(f"""
                <div class="val-row">
                    <div class="val-name"><b>{comp.get('name','')}</b> — {comp.get('description','')}</div>
                    <div><span class="badge {badge_type}">{comp.get('type','')}</span></div>
                </div>
                """, unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)

    with tabs[1]:
        st.markdown('<div class="card-title">🗃 Data Model Design</div>', unsafe_allow_html=True)
        for table in td.get("data_model", {}).get("tables", []):
            with st.expander(f"📦 {table.get('name','?')} — {table.get('action','create').upper()}"):
                st.markdown(f"**Purpose:** {table.get('purpose','')}")
                st.markdown(f"**Table Group:** `{table.get('table_group','')}`")
                st.markdown(f"**Cache Lookup:** `{table.get('cache_lookup','')}`")
                if table.get("fields"):
                    st.markdown("**Field Design:**")
                    field_data = []
                    for f in table["fields"]:
                        field_data.append({
                            "Name": f.get("name",""),
                            "EDT/Type": f.get("type",""),
                            "Label": f.get("label",""),
                            "Mandatory": "✓" if f.get("mandatory") else "",
                            "Index": "✓" if f.get("indexed") else "",
                        })
                    import pandas as pd
                    st.dataframe(pd.DataFrame(field_data), use_container_width=True, hide_index=True)
                if table.get("relations"):
                    st.markdown("**Relations:**")
                    for rel in table["relations"]:
                        st.markdown(f"- → `{rel.get('related_table','')}` on `{rel.get('field','')}`")

    with tabs[2]:
        st.markdown('<div class="card-title">🧩 X++ Class Design</div>', unsafe_allow_html=True)
        for cls in td.get("class_design", []):
            with st.expander(f"⚙️ {cls.get('name','')} ({cls.get('type','')})"):
                st.markdown(f"**Purpose:** {cls.get('purpose','')}")
                st.markdown(f"**Extends:** `{cls.get('extends','Object')}`")
                if cls.get("methods"):
                    st.markdown("**Methods:**")
                    for m in cls["methods"]:
                        st.markdown(f"""
                        <div class="val-row">
                            <div class="val-icon">🔧</div>
                            <div class="val-name"><code>{m.get('name','')}</code> — {m.get('description','')}</div>
                            <div><span class="badge badge-purple">{m.get('modifier','public')}</span></div>
                        </div>
                        """, unsafe_allow_html=True)

    with tabs[3]:
        st.markdown('<div class="card-title">🔀 Process Flows</div>', unsafe_allow_html=True)
        for flow in td.get("process_flows", []):
            st.markdown(f"**{flow.get('name','')}**")
            for i, step in enumerate(flow.get("steps", []), 1):
                st.markdown(f"`Step {i}` → {step}")
            st.markdown("---")

    with tabs[4]:
        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown(td.get("full_tdd_markdown", "No TDD generated."), unsafe_allow_html=False)
        st.markdown('</div>', unsafe_allow_html=True)

    with tabs[5]:
        tdd_text = td.get("full_tdd_markdown", "")
        st.download_button(
            label="⬇ Download TDD as Markdown",
            data=tdd_text,
            file_name=f"{st.session_state.project_name or 'project'}_TDD.md",
            mime="text/markdown",
            use_container_width=True
        )
        st.json(td, expanded=False)
