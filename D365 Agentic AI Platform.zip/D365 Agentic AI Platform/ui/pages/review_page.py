import streamlit as st
import json
import zipfile
import io
from datetime import datetime
from ui.layout import render_pipeline_progress


def render_review_page():
    render_pipeline_progress()

    st.markdown('<div class="section-title">✅ Review & Export</div>', unsafe_allow_html=True)
    st.markdown('<div class="section-subtitle">Full pipeline review — requirements, design, and generated X++ artifacts. Export everything as a packaged bundle.</div>', unsafe_allow_html=True)

    if not st.session_state.xpp_code:
        st.warning("⚠️ Complete the pipeline first.")
        if st.button("← Back to Code Generation"):
            st.session_state.current_page = "codegen"
            st.rerun()
        return

    # Final scorecard
    artifacts   = st.session_state.xpp_code or {}
    val_report  = st.session_state.validation_report or {}
    req         = st.session_state.requirements or {}
    td          = st.session_state.technical_design or {}

    total_arts  = len(artifacts)
    passed      = sum(1 for v in val_report.values() if v.get("valid"))
    avg_score   = int(sum(v.get("confidence_score", 0) for v in val_report.values()) / max(total_arts, 1))
    total_loc   = sum(len(a["code"].splitlines()) for a in artifacts.values())

    # Hero scorecard
    st.markdown(f"""
    <div style="background:linear-gradient(135deg,#0e0e28,#131330);border:1px solid #2a2a5a;
                border-radius:16px;padding:2rem;margin-bottom:1.5rem;text-align:center;">
        <div style="font-size:0.78rem;font-weight:600;text-transform:uppercase;letter-spacing:0.1em;
                    color:#6366f1;margin-bottom:0.8rem;">Pipeline Complete</div>
        <div style="display:flex;justify-content:center;gap:3rem;flex-wrap:wrap;">
            <div>
                <div style="font-size:2.5rem;font-weight:700;
                            background:linear-gradient(135deg,#a78bfa,#60a5fa);
                            -webkit-background-clip:text;-webkit-text-fill-color:transparent">
                    {avg_score}%</div>
                <div style="font-size:0.75rem;color:#6b7280;text-transform:uppercase;letter-spacing:0.06em">
                    Avg Confidence</div>
            </div>
            <div>
                <div style="font-size:2.5rem;font-weight:700;color:#34d399">{passed}/{total_arts}</div>
                <div style="font-size:0.75rem;color:#6b7280;text-transform:uppercase;letter-spacing:0.06em">
                    Artifacts Valid</div>
            </div>
            <div>
                <div style="font-size:2.5rem;font-weight:700;color:#60a5fa">{total_loc:,}</div>
                <div style="font-size:0.75rem;color:#6b7280;text-transform:uppercase;letter-spacing:0.06em">
                    Lines of Code</div>
            </div>
            <div>
                <div style="font-size:2.5rem;font-weight:700;color:#fbbf24">
                    {len(req.get('business_rules',[]))}</div>
                <div style="font-size:0.75rem;color:#6b7280;text-transform:uppercase;letter-spacing:0.06em">
                    Rules Implemented</div>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)

    # Export bundle
    col1, col2 = st.columns([2, 1])
    with col1:
        tabs = st.tabs(["📦 All Artifacts", "📋 Requirements", "🏗 Tech Design", "📊 Validation"])

        with tabs[0]:
            for key, art in artifacts.items():
                val = val_report.get(key, {})
                score = val.get("confidence_score", 0)
                valid_icon = "✅" if val.get("valid") else "⚠️"
                color = "#34d399" if score >= 80 else "#fbbf24" if score >= 60 else "#f87171"
                with st.expander(f"{valid_icon} {art['name']} ({art['type']}) — {score}%"):
                    st.code(art["code"], language="csharp")

        with tabs[1]:
            st.markdown("### Requirements Summary")
            st.markdown(f"**Executive Summary:** {req.get('executive_summary','N/A')}")
            st.markdown(f"**Complexity:** `{req.get('complexity','Medium')}`")
            st.markdown(f"**Effort:** `{req.get('estimated_effort','N/A')}`")
            st.markdown("### Entities")
            for e in req.get("entities", []):
                st.markdown(f"- **{e.get('name','')}**: {e.get('description','')}")
            st.markdown("### Business Rules")
            for i, r in enumerate(req.get("business_rules", []), 1):
                st.markdown(f"{i}. {r.get('rule','')}")

        with tabs[2]:
            st.markdown(td.get("full_tdd_markdown", "No TDD available."))

        with tabs[3]:
            st.markdown("### Validation Summary")
            for key, val in val_report.items():
                art = artifacts.get(key, {})
                status = "✅ PASS" if val.get("valid") else "❌ FAIL"
                score = val.get("confidence_score", 0)
                st.markdown(f"**{art.get('name','?')}** — {status} ({score}% confidence)")
                if val.get("errors"):
                    for e in val["errors"]:
                        st.markdown(f"  - 🔴 {e}")
                if val.get("warnings"):
                    for w in val["warnings"]:
                        st.markdown(f"  - 🟡 {w}")
                st.markdown("---")

    with col2:
        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown('<div class="card-title">⬇ Export Options</div>', unsafe_allow_html=True)

        project = st.session_state.project_name or "project"
        timestamp = datetime.now().strftime("%Y%m%d_%H%M")

        # Individual artifact downloads
        st.markdown("**Individual Files:**")
        for key, art in artifacts.items():
            st.download_button(
                label=f"⬇ {art['name']}.xpp",
                data=art["code"],
                file_name=f"{art['name']}.xpp",
                mime="text/plain",
                key=f"review_dl_{key}"
            )

        st.markdown("---")
        st.markdown("**Bundle Downloads:**")

        # ZIP of all X++ files
        zip_buf = io.BytesIO()
        with zipfile.ZipFile(zip_buf, "w") as zf:
            for key, art in artifacts.items():
                zf.writestr(f"xpp/{art['name']}.xpp", art["code"])
            if td.get("full_tdd_markdown"):
                zf.writestr(f"docs/{project}_TDD.md", td["full_tdd_markdown"])
            zf.writestr(
                f"docs/{project}_requirements.json",
                json.dumps(req, indent=2)
            )
            val_lines = [f"# Validation Report — {project}\n"]
            for key, val in val_report.items():
                art = artifacts.get(key, {})
                val_lines.append(f"\n## {art.get('name','?')}")
                val_lines.append(f"Status: {'PASS' if val.get('valid') else 'FAIL'}")
                val_lines.append(f"Confidence: {val.get('confidence_score',0)}%")
                for e in val.get("errors", []):
                    val_lines.append(f"- ERROR: {e}")
                for w in val.get("warnings", []):
                    val_lines.append(f"- WARN: {w}")
            zf.writestr(f"docs/{project}_validation.md", "\n".join(val_lines))
        zip_buf.seek(0)

        st.download_button(
            label="📦 Download Full Bundle (.zip)",
            data=zip_buf,
            file_name=f"{project}_{timestamp}_xpp_bundle.zip",
            mime="application/zip",
            use_container_width=True
        )

        # TDD only
        if td.get("full_tdd_markdown"):
            st.download_button(
                label="📄 Download TDD (.md)",
                data=td["full_tdd_markdown"],
                file_name=f"{project}_TDD.md",
                mime="text/markdown",
                use_container_width=True
            )

        # Requirements JSON
        st.download_button(
            label="📋 Download Requirements (.json)",
            data=json.dumps(req, indent=2),
            file_name=f"{project}_requirements.json",
            mime="application/json",
            use_container_width=True
        )

        st.markdown('</div>', unsafe_allow_html=True)

        # Reset pipeline
        st.markdown('<div class="glass-card" style="margin-top:1rem">', unsafe_allow_html=True)
        st.markdown('<div class="card-title">🔄 New Analysis</div>', unsafe_allow_html=True)
        st.markdown('<div style="font-size:0.78rem;color:#6b7280;margin-bottom:0.8rem">Start a fresh pipeline with a new FDD.</div>', unsafe_allow_html=True)
        if st.button("🗑 Reset Pipeline", use_container_width=True):
            for key in ["fdd_raw_text","fdd_filename","fdd_metadata","requirements",
                        "technical_design","xpp_code","validation_report","pipeline_stage"]:
                st.session_state[key] = None if key != "pipeline_stage" else 0
                if key in ("fdd_metadata",):
                    st.session_state[key] = {}
            st.session_state.current_page = "upload"
            st.rerun()
        st.markdown('</div>', unsafe_allow_html=True)
