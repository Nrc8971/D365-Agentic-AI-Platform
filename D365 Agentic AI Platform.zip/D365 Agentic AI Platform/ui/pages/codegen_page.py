import streamlit as st
import time
from ui.layout import render_pipeline_progress
from ai_engine.xpp_generator import XppGenerator
from ai_engine.code_validator import CodeValidator


def render_codegen_page():
    render_pipeline_progress()

    st.markdown('<div class="section-title">⚙️ X++ Code Generation</div>', unsafe_allow_html=True)
    st.markdown('<div class="section-subtitle">AI generates production-grade X++ code with multi-layer validation, naming enforcement, and automatic retry on failure.</div>', unsafe_allow_html=True)

    if not st.session_state.technical_design:
        st.warning("⚠️ Run Technical Design first.")
        if st.button("← Back to Design"):
            st.session_state.current_page = "design"
            st.rerun()
        return

    if not st.session_state.xpp_code:
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            st.markdown("""
            <div class="glass-card" style="text-align:center; padding:2.5rem;">
                <div style="font-size:3rem; margin-bottom:1rem;">⚙️</div>
                <div style="font-size:1.1rem; font-weight:600; color:#e2e2f0; margin-bottom:0.5rem;">Ready to Generate X++ Code</div>
                <div style="font-size:0.82rem; color:#6b7280; margin-bottom:1.5rem;">
                    Claude generates validated X++ artifacts — table extensions, service classes, 
                    event handlers, forms — with 5-layer validation and auto-retry.
                </div>
            </div>
            """, unsafe_allow_html=True)
            if st.button("⚡ Generate X++ Code", use_container_width=True):
                _run_codegen()
    else:
        _display_codegen()
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            if st.button("✅ Review & Export →", use_container_width=True):
                st.session_state.current_page = "review"
                st.rerun()
        with col1:
            if st.button("🔄 Regenerate", use_container_width=True):
                st.session_state.xpp_code = None
                st.session_state.validation_report = None
                st.rerun()


def _get_active_key_and_provider():
    provider = st.session_state.get("ai_provider", "anthropic")
    if provider == "google":
        return st.session_state.get("google_api_key", ""), "google"
    return st.session_state.get("api_key", ""), "anthropic"


def _run_codegen():
    key, provider = _get_active_key_and_provider()
    generator = XppGenerator(api_key=key, provider=provider)
    validator = CodeValidator()

    context = {
        "project_name": st.session_state.project_name,
        "model_prefix": st.session_state.model_prefix,
        "d365_module": st.session_state.d365_module,
        "enforce_naming": st.session_state.get("enforce_naming", True),
        "add_error_handling": st.session_state.get("add_error_handling", True),
        "add_comments": st.session_state.get("add_comments", True),
    }

    progress = st.progress(0, text="Initializing X++ generator...")
    status = st.empty()
    detail = st.empty()

    try:
        artifacts = {}
        validation_results = {}
        td = st.session_state.technical_design
        req = st.session_state.requirements

        # Collect what to generate
        gen_targets = st.session_state.get("gen_targets", [])
        total = len(td.get("class_design", [])) + len(td.get("data_model", {}).get("tables", []))
        done = 0

        # Generate table extensions
        status.markdown("<div style='font-size:0.82rem;color:#60a5fa'>🗃 Generating table extensions...</div>", unsafe_allow_html=True)
        for table in td.get("data_model", {}).get("tables", []):
            if table.get("action") in ("extend", "create"):
                art_key = f"table_{table['name']}"
                code = generator.generate_table_extension(table, req, context)
                val = validator.validate(code, context, artifact_type="table")
                artifacts[art_key] = {"code": code, "type": "Table Extension", "name": table["name"]}
                validation_results[art_key] = val
                done += 1
                progress.progress(done / max(total, 1) * 0.5, text=f"Tables: {table['name']}")
                time.sleep(0.1)

        # Generate service classes
        status.markdown("<div style='font-size:0.82rem;color:#a78bfa'>🧩 Generating service classes...</div>", unsafe_allow_html=True)
        for cls in td.get("class_design", []):
            art_key = f"class_{cls['name']}"
            code = generator.generate_class(cls, req, context)
            val = validator.validate(code, context, artifact_type="class")
            artifacts[art_key] = {"code": code, "type": cls.get("type", "Class"), "name": cls["name"]}
            validation_results[art_key] = val
            done += 1
            progress.progress(0.5 + done / max(total, 1) * 0.5, text=f"Class: {cls['name']}")
            time.sleep(0.1)

        # Retry failed validations if strict mode
        if st.session_state.get("strict_validation", True):
            for key, val in validation_results.items():
                if not val["valid"] and val.get("retryable"):
                    status.markdown("<div style='font-size:0.82rem;color:#fbbf24'>🔄 Auto-retrying failed artifacts...</div>", unsafe_allow_html=True)
                    art = artifacts[key]
                    retry_code = generator.retry_with_corrections(
                        art["code"], val, context
                    )
                    if retry_code:
                        artifacts[key]["code"] = retry_code
                        validation_results[key] = validator.validate(retry_code, context, art.get("type", "class").lower())

        st.session_state.xpp_code = artifacts
        st.session_state.validation_report = validation_results
        st.session_state.pipeline_stage = 4

        progress.progress(1.0, text="✅ Code generation complete!")
        status.empty()
        detail.empty()
        st.rerun()

    except Exception as e:
        progress.empty()
        status.empty()
        detail.empty()
        st.error(f"Code generation failed: {str(e)}")
        import traceback
        with st.expander("Error details"):
            st.code(traceback.format_exc())


def _display_codegen():
    artifacts = st.session_state.xpp_code
    val_report = st.session_state.validation_report or {}

    # Summary metrics
    total = len(artifacts)
    passed = sum(1 for k, v in val_report.items() if v.get("valid", False))
    avg_score = int(sum(v.get("confidence_score", 0) for v in val_report.values()) / max(total, 1))

    cols = st.columns(4)
    with cols[0]:
        st.markdown(f'<div class="metric-tile"><div class="metric-value">{total}</div><div class="metric-label">Artifacts</div></div>', unsafe_allow_html=True)
    with cols[1]:
        st.markdown(f'<div class="metric-tile"><div class="metric-value">{passed}</div><div class="metric-label">Passed Validation</div></div>', unsafe_allow_html=True)
    with cols[2]:
        color = "#34d399" if avg_score >= 80 else "#fbbf24" if avg_score >= 60 else "#f87171"
        st.markdown(f'<div class="metric-tile"><div class="metric-value" style="background:none;-webkit-text-fill-color:{color}">{avg_score}%</div><div class="metric-label">Avg Confidence</div></div>', unsafe_allow_html=True)
    with cols[3]:
        warnings = sum(len(v.get("warnings", [])) for v in val_report.values())
        st.markdown(f'<div class="metric-tile"><div class="metric-value">{warnings}</div><div class="metric-label">Warnings</div></div>', unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # Artifact tabs
    artifact_names = list(artifacts.keys())
    if not artifact_names:
        st.info("No artifacts generated.")
        return

    tab_labels = [f"{artifacts[k]['type'][:1]}· {artifacts[k]['name']}" for k in artifact_names]
    tabs = st.tabs(tab_labels + ["📊 Validation Report"])

    for i, key in enumerate(artifact_names):
        with tabs[i]:
            art = artifacts[key]
            val = val_report.get(key, {})

            # Header
            col1, col2, col3 = st.columns([3, 1, 1])
            with col1:
                st.markdown(f"**{art['name']}** — `{art['type']}`")
            with col2:
                score = val.get("confidence_score", 0)
                color = "#34d399" if score >= 80 else "#fbbf24" if score >= 60 else "#f87171"
                st.markdown(f'<div class="badge" style="background:rgba(0,0,0,0.2);border:1px solid {color};color:{color}">⚡ {score}% confidence</div>', unsafe_allow_html=True)
            with col3:
                status_cls = "badge-green" if val.get("valid") else "badge-red"
                status_txt = "✓ VALID" if val.get("valid") else "⚠ ISSUES"
                st.markdown(f'<div class="badge {status_cls}">{status_txt}</div>', unsafe_allow_html=True)

            # Validation issues inline
            if val.get("errors"):
                with st.expander(f"🔴 {len(val['errors'])} Errors", expanded=True):
                    for e in val["errors"]:
                        st.markdown(f"<div style='color:#f87171;font-size:0.8rem'>• {e}</div>", unsafe_allow_html=True)
            if val.get("warnings"):
                with st.expander(f"🟡 {len(val['warnings'])} Warnings"):
                    for w in val["warnings"]:
                        st.markdown(f"<div style='color:#fbbf24;font-size:0.8rem'>• {w}</div>", unsafe_allow_html=True)

            # Code display
            st.markdown('<div class="card-title" style="margin-top:0.8rem">💻 Generated Code</div>', unsafe_allow_html=True)
            st.code(art["code"], language="csharp")  # closest highlight to X++

            # Download button
            st.download_button(
                f"⬇ Download {art['name']}.xpp",
                data=art["code"],
                file_name=f"{art['name']}.xpp",
                mime="text/plain",
                key=f"dl_{key}"
            )

    # Validation Report tab
    with tabs[-1]:
        st.markdown('<div class="card-title">📊 Validation Report — All Artifacts</div>', unsafe_allow_html=True)
        for key, val in val_report.items():
            art = artifacts.get(key, {})
            score = val.get("confidence_score", 0)
            color = "#34d399" if score >= 80 else "#fbbf24" if score >= 60 else "#f87171"
            valid_icon = "✅" if val.get("valid") else "❌"
            st.markdown(f"""
            <div class="val-row">
                <div class="val-icon">{valid_icon}</div>
                <div class="val-name"><b>{art.get('name','?')}</b></div>
                <div style="font-size:0.78rem;color:#6b7280">{art.get('type','')}</div>
                <div class="val-score" style="color:{color}">{score}%</div>
            </div>
            """, unsafe_allow_html=True)
            for check in val.get("checks", []):
                icon = "✅" if check["status"] == "pass" else "⚠️" if check["status"] == "warning" else "❌"
                st.markdown(f"""
                <div style="padding:0.3rem 2rem;font-size:0.75rem;color:#6b7280">
                    {icon} <b>{check['name']}</b>: {check['message']}
                </div>
                """, unsafe_allow_html=True)
