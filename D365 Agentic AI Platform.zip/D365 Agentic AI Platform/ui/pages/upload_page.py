import streamlit as st
from ui.layout import render_pipeline_progress
from utils.fdd_parser import parse_fdd_file


def render_upload_page():
    render_pipeline_progress()

    st.markdown('<div class="section-title">📄 Upload Functional Design Document</div>', unsafe_allow_html=True)
    st.markdown('<div class="section-subtitle">Upload your FDD in PDF or DOCX format. The AI engine will extract, structure, and prepare it for analysis.</div>', unsafe_allow_html=True)

    col1, col2 = st.columns([3, 2], gap="large")

    with col1:
        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown('<div class="card-title">📂 Document Upload</div>', unsafe_allow_html=True)

        uploaded = st.file_uploader(
            "Drop your FDD here",
            type=["pdf", "docx", "txt"],
            help="Supported: PDF, DOCX, TXT. Max 50MB.",
            label_visibility="collapsed"
        )

        if uploaded:
            with st.spinner("🔍 Parsing document..."):
                try:
                    text, metadata = parse_fdd_file(uploaded)
                    st.session_state.fdd_raw_text = text
                    st.session_state.fdd_filename = uploaded.name
                    st.session_state.fdd_metadata = metadata
                    st.session_state.pipeline_stage = 1
                except Exception as e:
                    st.error(f"Failed to parse document: {e}")

        if st.session_state.fdd_raw_text:
            meta = st.session_state.fdd_metadata
            st.markdown(f"""
            <div style="background:#0d1a0d; border:1px solid #1a4a1a; border-radius:10px; padding:1rem; margin-top:1rem;">
                <div style="color:#34d399; font-weight:600; margin-bottom:0.6rem;">✅ Document loaded successfully</div>
                <div style="font-size:0.82rem; color:#6b7280;">
                    <b style="color:#9ca3af">File:</b> {st.session_state.fdd_filename}<br>
                    <b style="color:#9ca3af">Pages:</b> {meta.get('pages', 'N/A')} &nbsp;|&nbsp;
                    <b style="color:#9ca3af">Words:</b> {meta.get('word_count', 0):,} &nbsp;|&nbsp;
                    <b style="color:#9ca3af">Type:</b> {meta.get('file_type', 'N/A').upper()}
                </div>
            </div>
            """, unsafe_allow_html=True)

            with st.expander("👁 Preview extracted text (first 1500 chars)"):
                st.markdown(f"""
                <div class="xpp-code-block" style="white-space:pre-wrap; font-family: 'Inter', sans-serif; font-size:0.78rem;">
{st.session_state.fdd_raw_text[:1500]}...</div>
                """, unsafe_allow_html=True)

        st.markdown('</div>', unsafe_allow_html=True)

    with col2:
        # Configuration card
        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown('<div class="card-title">🎯 Generation Scope</div>', unsafe_allow_html=True)

        gen_targets = st.multiselect(
            "What to generate",
            ["Requirements Analysis", "Technical Design Doc", "X++ Table Extensions",
             "X++ Service Classes", "X++ Form Extensions", "X++ Event Handlers",
             "X++ Enums & EDTs", "DevOps Tasks"],
            default=["Requirements Analysis", "Technical Design Doc",
                     "X++ Table Extensions", "X++ Service Classes"],
            help="Select which artifacts to generate from the FDD"
        )
        st.session_state.gen_targets = gen_targets

        st.markdown('<div class="card-title" style="margin-top:1rem">🛡 Quality Controls</div>', unsafe_allow_html=True)

        st.session_state.enforce_naming = st.toggle("Enforce naming conventions", value=True)
        st.session_state.validate_model = st.toggle("Validate against D365 model", value=True)
        st.session_state.add_error_handling = st.toggle("Add ttsBegin/ttsCommit", value=True)
        st.session_state.add_comments = st.toggle("Add XML doc comments", value=True)
        st.session_state.strict_validation = st.toggle("Strict validation (retry on fail)", value=True)

        st.markdown('</div>', unsafe_allow_html=True)

        # Tips card
        st.markdown("""
        <div class="glass-card">
            <div class="card-title">💡 FDD Tips for Best Results</div>
            <div style="font-size:0.78rem; color:#6b7280; line-height:1.7;">
                ✦ Include table/field names explicitly<br>
                ✦ List business rules in numbered format<br>
                ✦ Specify module context (Sales, WMS, etc.)<br>
                ✦ Name any existing tables to extend<br>
                ✦ Describe UI/form requirements clearly<br>
                ✦ Include integration points if any
            </div>
        </div>
        """, unsafe_allow_html=True)

    # CTA
    if st.session_state.fdd_raw_text:
        st.markdown("<br>", unsafe_allow_html=True)
        col_cta1, col_cta2, col_cta3 = st.columns([1, 2, 1])
        with col_cta2:
            provider = st.session_state.get("ai_provider", "anthropic")
            active_key = (
                st.session_state.get("api_key", "")
                if provider == "anthropic"
                else st.session_state.get("google_api_key", "")
            )
            if not active_key:
                provider_label = "Anthropic" if provider == "anthropic" else "Google Gemini"
                st.warning(f"⚠️ Add your {provider_label} API key in the sidebar to proceed")
            else:
                if st.button("🚀 Begin AI Analysis →", use_container_width=True):
                    st.session_state.current_page = "analysis"
                    st.rerun()
