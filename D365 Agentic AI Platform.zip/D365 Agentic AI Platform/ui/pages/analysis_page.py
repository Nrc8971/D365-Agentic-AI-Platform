import streamlit as st
import time
from ui.layout import render_pipeline_progress
from ai_engine.requirement_analyzer import RequirementAnalyzer


def render_analysis_page():
    render_pipeline_progress()

    st.markdown('<div class="section-title">🔍 Requirements Analysis</div>', unsafe_allow_html=True)
    st.markdown('<div class="section-subtitle">AI extracts structured requirements, entities, business rules, and D365 metadata from your FDD.</div>', unsafe_allow_html=True)

    if not st.session_state.fdd_raw_text:
        st.warning("⚠️ No FDD loaded. Go back to Upload.")
        if st.button("← Back to Upload"):
            st.session_state.current_page = "upload"
            st.rerun()
        return

    # Run analysis if not done
    if not st.session_state.requirements:
        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            st.markdown("""
            <div class="glass-card" style="text-align:center; padding:2.5rem;">
                <div style="font-size:3rem; margin-bottom:1rem;">🔍</div>
                <div style="font-size:1.1rem; font-weight:600; color:#e2e2f0; margin-bottom:0.5rem;">Ready to Analyze</div>
                <div style="font-size:0.82rem; color:#6b7280; margin-bottom:1.5rem;">
                    Claude will extract all requirements, entities, tables, fields, business rules, 
                    validation logic, and integration points from your FDD.
                </div>
            </div>
            """, unsafe_allow_html=True)
            if st.button("🔍 Run Requirements Extraction", use_container_width=True):
                _run_analysis()

    else:
        _display_requirements()

        col1, col2, col3 = st.columns([1, 2, 1])
        with col2:
            if st.button("🏗 Proceed to Technical Design →", use_container_width=True):
                st.session_state.current_page = "design"
                st.rerun()
        with col1:
            if st.button("🔄 Re-analyze", use_container_width=True):
                st.session_state.requirements = None
                st.rerun()


def _get_active_key_and_provider():
    """Return (api_key, provider) based on sidebar selection."""
    provider = st.session_state.get("ai_provider", "anthropic")
    if provider == "google":
        return st.session_state.get("google_api_key", ""), "google"
    return st.session_state.get("api_key", ""), "anthropic"


def _run_analysis():
    key, provider = _get_active_key_and_provider()
    analyzer = RequirementAnalyzer(api_key=key, provider=provider)
    context = {
        "project_name": st.session_state.project_name,
        "model_prefix": st.session_state.model_prefix,
        "d365_module": st.session_state.d365_module,
    }

    progress = st.progress(0, text="Initializing AI engine...")
    status = st.empty()

    stages = [
        (15, "📖 Reading and chunking FDD..."),
        (35, "🔍 Extracting business entities..."),
        (55, "📋 Identifying business rules..."),
        (75, "🗄 Mapping D365 tables & fields..."),
        (90, "🔗 Detecting integrations & flows..."),
        (100, "✅ Requirements extracted!"),
    ]

    try:
        for pct, msg in stages[:-1]:
            progress.progress(pct / 100, text=msg)
            status.markdown(f"<div style='font-size:0.82rem;color:#a78bfa'>{msg}</div>", unsafe_allow_html=True)
            time.sleep(0.3)

        result = analyzer.analyze(st.session_state.fdd_raw_text, context)
        st.session_state.requirements = result
        st.session_state.pipeline_stage = 2

        progress.progress(1.0, text="✅ Done!")
        status.empty()
        st.rerun()

    except Exception as e:
        progress.empty()
        status.empty()
        st.error(f"Analysis failed: {str(e)}")


def _display_requirements():
    req = st.session_state.requirements

    # Summary metrics
    cols = st.columns(5)
    metrics = [
        ("Entities", len(req.get("entities", []))),
        ("Tables", len(req.get("tables_to_create", [])) + len(req.get("tables_to_extend", []))),
        ("Business Rules", len(req.get("business_rules", []))),
        ("Integrations", len(req.get("integrations", []))),
        ("Validations", len(req.get("validations", []))),
    ]
    for col, (label, val) in zip(cols, metrics):
        with col:
            st.markdown(f"""
            <div class="metric-tile">
                <div class="metric-value">{val}</div>
                <div class="metric-label">{label}</div>
            </div>
            """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    tabs = st.tabs(["📋 Entities & Tables", "📏 Business Rules", "✔ Validations",
                    "🔗 Integrations", "🗒 Summary", "📄 Raw JSON"])

    with tabs[0]:
        col1, col2 = st.columns(2)
        with col1:
            st.markdown('<div class="card-title">🆕 Tables to Create</div>', unsafe_allow_html=True)
            for t in req.get("tables_to_create", []):
                with st.expander(f"📦 {t.get('name', 'Unknown')}"):
                    st.markdown(f"**Purpose:** {t.get('purpose', 'N/A')}")
                    st.markdown(f"**Module:** {t.get('module', 'N/A')}")
                    if t.get("fields"):
                        st.markdown("**Fields:**")
                        for f in t["fields"]:
                            dtype = f.get('type', '')
                            st.markdown(f"- `{f.get('name','?')}` — {dtype} {'_(PK)_' if f.get('is_key') else ''} {'_(Mandatory)_' if f.get('mandatory') else ''}")
        with col2:
            st.markdown('<div class="card-title">🔧 Tables to Extend</div>', unsafe_allow_html=True)
            for t in req.get("tables_to_extend", []):
                with st.expander(f"🔩 {t.get('name', 'Unknown')}"):
                    st.markdown(f"**Reason:** {t.get('reason', 'N/A')}")
                    if t.get("fields_to_add"):
                        st.markdown("**New fields:**")
                        for f in t["fields_to_add"]:
                            st.markdown(f"- `{f.get('name','?')}` — {f.get('type','')}")

    with tabs[1]:
        for i, rule in enumerate(req.get("business_rules", []), 1):
            priority = rule.get("priority", "medium")
            badge_cls = {"high": "badge-red", "medium": "badge-amber", "low": "badge-green"}.get(priority, "badge-blue")
            st.markdown(f"""
            <div class="val-row">
                <div class="val-icon">📋</div>
                <div class="val-name"><b>BR-{i:02d}:</b> {rule.get('rule', '')}</div>
                <div><span class="badge {badge_cls}">{priority.upper()}</span></div>
            </div>
            """, unsafe_allow_html=True)

    with tabs[2]:
        for v in req.get("validations", []):
            st.markdown(f"""
            <div class="val-row">
                <div class="val-icon">✔</div>
                <div class="val-name">{v.get('description', '')}</div>
                <div><span class="badge badge-blue">{v.get('type', 'field')}</span></div>
            </div>
            """, unsafe_allow_html=True)

    with tabs[3]:
        for intg in req.get("integrations", []):
            st.markdown(f"""
            <div class="val-row">
                <div class="val-icon">🔗</div>
                <div class="val-name"><b>{intg.get('system', '')}:</b> {intg.get('description', '')}</div>
                <div><span class="badge badge-purple">{intg.get('type', 'API')}</span></div>
            </div>
            """, unsafe_allow_html=True)

    with tabs[4]:
        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown(f"**Executive Summary:**\n\n{req.get('executive_summary', 'N/A')}")
        st.markdown(f"\n**Complexity:** `{req.get('complexity', 'Medium')}`")
        st.markdown(f"\n**Estimated Effort:** `{req.get('estimated_effort', 'N/A')}`")
        st.markdown(f"\n**Key Risks:**")
        for risk in req.get("risks", []):
            st.markdown(f"- ⚠️ {risk}")
        st.markdown('</div>', unsafe_allow_html=True)

    with tabs[5]:
        st.json(req)
