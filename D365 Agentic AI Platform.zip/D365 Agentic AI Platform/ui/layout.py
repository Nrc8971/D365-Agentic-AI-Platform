import streamlit as st


def inject_custom_css():
    st.markdown("""
    <style>
    /* ── Reset & Base ── */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

    html, body, [class*="css"] {
        font-family: 'Inter', sans-serif;
    }

    .stApp {
        background: #0a0a0f;
        color: #e8e8f0;
    }

    /* ── Hide default Streamlit decoration ── */
    #MainMenu, footer, header { visibility: hidden; }
    .block-container { padding-top: 1rem !important; }

    /* ── Sidebar ── */
    section[data-testid="stSidebar"] {
        background: #0e0e18 !important;
        border-right: 1px solid #1e1e30 !important;
    }
    section[data-testid="stSidebar"] * { color: #c8c8d8 !important; }

    /* ── Header bar ── */
    .platform-header {
        background: linear-gradient(135deg, #0e0e20 0%, #161630 100%);
        border: 1px solid #2a2a4a;
        border-radius: 14px;
        padding: 1.5rem 2rem;
        margin-bottom: 1.5rem;
        display: flex;
        align-items: center;
        gap: 1rem;
    }
    .platform-header h1 {
        font-size: 1.6rem;
        font-weight: 700;
        background: linear-gradient(135deg, #a78bfa, #60a5fa, #34d399);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin: 0;
    }
    .platform-header .subtitle {
        font-size: 0.82rem;
        color: #6b7280;
        margin-top: 2px;
    }

    /* ── Pipeline progress bar ── */
    .pipeline-track {
        background: #111124;
        border: 1px solid #1e1e35;
        border-radius: 12px;
        padding: 1.2rem 1.6rem;
        margin-bottom: 1.5rem;
    }
    .pipeline-steps {
        display: flex;
        align-items: center;
        gap: 0;
    }
    .pip-step {
        display: flex;
        flex-direction: column;
        align-items: center;
        flex: 1;
        position: relative;
    }
    .pip-dot {
        width: 36px; height: 36px;
        border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        font-size: 0.85rem;
        font-weight: 600;
        border: 2px solid #2a2a4a;
        background: #111124;
        color: #4b5563;
        z-index: 2;
        transition: all 0.3s;
    }
    .pip-dot.active {
        background: linear-gradient(135deg, #7c3aed, #2563eb);
        border-color: #7c3aed;
        color: white;
        box-shadow: 0 0 16px rgba(124,58,237,0.4);
    }
    .pip-dot.done {
        background: linear-gradient(135deg, #059669, #10b981);
        border-color: #059669;
        color: white;
    }
    .pip-label {
        font-size: 0.7rem;
        margin-top: 6px;
        color: #4b5563;
        text-align: center;
        white-space: nowrap;
    }
    .pip-label.active { color: #a78bfa; }
    .pip-label.done   { color: #34d399; }
    .pip-line {
        flex: 1;
        height: 2px;
        background: #1e1e35;
        margin-top: -18px;
        z-index: 1;
    }
    .pip-line.done { background: linear-gradient(90deg, #059669, #10b981); }

    /* ── Cards ── */
    .glass-card {
        background: #111124;
        border: 1px solid #1e1e35;
        border-radius: 14px;
        padding: 1.5rem;
        margin-bottom: 1rem;
    }
    .card-title {
        font-size: 0.78rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: #6366f1;
        margin-bottom: 0.8rem;
        display: flex;
        align-items: center;
        gap: 0.4rem;
    }

    /* ── Upload drop zone ── */
    .upload-zone {
        background: #0d0d1f;
        border: 2px dashed #2a2a50;
        border-radius: 16px;
        padding: 3rem 2rem;
        text-align: center;
        cursor: pointer;
        transition: border-color 0.3s, background 0.3s;
    }
    .upload-zone:hover {
        border-color: #7c3aed;
        background: #0f0f28;
    }
    .upload-icon { font-size: 3rem; margin-bottom: 0.8rem; }
    .upload-text { font-size: 1rem; color: #9ca3af; }
    .upload-sub  { font-size: 0.8rem; color: #4b5563; margin-top: 0.4rem; }

    /* ── Status badges ── */
    .badge {
        display: inline-flex; align-items: center; gap: 0.3rem;
        padding: 0.25rem 0.7rem;
        border-radius: 20px;
        font-size: 0.72rem;
        font-weight: 600;
    }
    .badge-purple { background: rgba(124,58,237,0.15); color: #a78bfa; border: 1px solid rgba(124,58,237,0.3); }
    .badge-green  { background: rgba(5,150,105,0.15);  color: #34d399;  border: 1px solid rgba(5,150,105,0.3); }
    .badge-blue   { background: rgba(37,99,235,0.15);  color: #60a5fa;  border: 1px solid rgba(37,99,235,0.3); }
    .badge-amber  { background: rgba(217,119,6,0.15);  color: #fbbf24;  border: 1px solid rgba(217,119,6,0.3); }
    .badge-red    { background: rgba(220,38,38,0.15);  color: #f87171;  border: 1px solid rgba(220,38,38,0.3); }

    /* ── Code block ── */
    .xpp-code-block {
        background: #070712;
        border: 1px solid #1e1e35;
        border-radius: 10px;
        padding: 1.2rem;
        font-family: 'JetBrains Mono', monospace;
        font-size: 0.8rem;
        line-height: 1.7;
        color: #c8c8e8;
        overflow-x: auto;
        white-space: pre;
    }

    /* ── Metric tile ── */
    .metric-tile {
        background: #111124;
        border: 1px solid #1e1e35;
        border-radius: 12px;
        padding: 1.1rem 1.3rem;
        text-align: center;
    }
    .metric-value {
        font-size: 2rem;
        font-weight: 700;
        background: linear-gradient(135deg, #a78bfa, #60a5fa);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
    .metric-label {
        font-size: 0.72rem;
        color: #6b7280;
        text-transform: uppercase;
        letter-spacing: 0.06em;
        margin-top: 4px;
    }

    /* ── Section divider ── */
    .section-title {
        font-size: 1.1rem;
        font-weight: 600;
        color: #e2e2f0;
        margin-bottom: 0.4rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    .section-subtitle {
        font-size: 0.82rem;
        color: #6b7280;
        margin-bottom: 1.2rem;
    }

    /* ── Validation result rows ── */
    .val-row {
        display: flex; align-items: center; gap: 0.8rem;
        padding: 0.6rem 0.8rem;
        border-radius: 8px;
        margin-bottom: 0.4rem;
        background: #0d0d1e;
        border: 1px solid #1a1a30;
        font-size: 0.82rem;
    }
    .val-icon { font-size: 1rem; }
    .val-name { flex: 1; color: #c8c8d8; }
    .val-score { font-weight: 600; font-size: 0.85rem; }

    /* ── Scrollbar ── */
    ::-webkit-scrollbar { width: 5px; height: 5px; }
    ::-webkit-scrollbar-track { background: #0a0a0f; }
    ::-webkit-scrollbar-thumb { background: #2a2a4a; border-radius: 4px; }

    /* ── Buttons ── */
    .stButton > button {
        background: linear-gradient(135deg, #7c3aed, #2563eb) !important;
        color: white !important;
        border: none !important;
        border-radius: 10px !important;
        font-weight: 600 !important;
        font-size: 0.9rem !important;
        padding: 0.6rem 2rem !important;
        transition: all 0.2s !important;
    }
    .stButton > button:hover {
        transform: translateY(-1px);
        box-shadow: 0 6px 20px rgba(124,58,237,0.35) !important;
    }

    /* ── Text inputs ── */
    .stTextInput > div > div > input,
    .stTextArea > div > div > textarea,
    .stSelectbox > div > div {
        background: #111124 !important;
        border: 1px solid #2a2a4a !important;
        border-radius: 8px !important;
        color: #e2e2f0 !important;
    }

    /* ── Expander ── */
    .streamlit-expanderHeader {
        background: #111124 !important;
        border-radius: 8px !important;
        color: #c8c8d8 !important;
    }

    /* ── Tab style ── */
    .stTabs [data-baseweb="tab-list"] {
        background: #111124;
        border-radius: 10px;
        padding: 4px;
        border: 1px solid #1e1e35;
        gap: 4px;
    }
    .stTabs [data-baseweb="tab"] {
        border-radius: 7px;
        color: #6b7280 !important;
        font-size: 0.82rem;
    }
    .stTabs [aria-selected="true"] {
        background: linear-gradient(135deg, rgba(124,58,237,0.25), rgba(37,99,235,0.25)) !important;
        color: #a78bfa !important;
    }

    /* ── Progress bar ── */
    .stProgress > div > div > div {
        background: linear-gradient(90deg, #7c3aed, #2563eb, #059669) !important;
    }

    /* ── Alert / info ── */
    .stAlert {
        background: #111124 !important;
        border: 1px solid #2a2a4a !important;
        border-radius: 10px !important;
    }
    </style>
    """, unsafe_allow_html=True)


def render_header():
    st.markdown("""
    <div class="platform-header">
        <div style="font-size:2rem">⚡</div>
        <div>
            <h1>D365 → Agentic AI Platform</h1>
            <div class="subtitle">Functional Design Document → Technical Design → Validated X++ Code for Dynamics 365 F&O</div>
        </div>
    </div>
    """, unsafe_allow_html=True)


def render_pipeline_progress():
    """Render horizontal pipeline progress tracker."""
    stage = st.session_state.pipeline_stage

    def step_class(s):
        if s < stage:  return "done"
        if s == stage: return "active"
        return ""

    def line_class(s):
        return "done" if s < stage else ""

    steps = [
        ("📄", "FDD Upload"),
        ("🔍", "Requirements"),
        ("🏗️", "Tech Design"),
        ("⚙️", "X++ Code"),
        ("✅", "Review"),
    ]

    html = '<div class="pipeline-track"><div class="pipeline-steps">'
    for i, (icon, label) in enumerate(steps):
        cls = step_class(i)
        html += f'''
        <div class="pip-step">
            <div class="pip-dot {cls}">{icon if cls == "done" else (i+1)}</div>
            <div class="pip-label {cls}">{label}</div>
        </div>'''
        if i < len(steps) - 1:
            html += f'<div class="pip-line {line_class(i)}"></div>'
    html += '</div></div>'
    st.markdown(html, unsafe_allow_html=True)


def render_sidebar():
    with st.sidebar:
        st.markdown("""
        <div style="padding: 1rem 0; border-bottom: 1px solid #1e1e35; margin-bottom: 1rem;">
            <div style="font-size: 1.1rem; font-weight: 700; color: #a78bfa;">⚡ D365 AI Agent</div>
            <div style="font-size: 0.72rem; color: #4b5563; margin-top: 2px;">D365 F&O Code Generator</div>
        </div>
        """, unsafe_allow_html=True)

        # ── AI Provider selector ──────────────────────────────────────────
        st.markdown('<div class="card-title">🤖 AI Provider</div>', unsafe_allow_html=True)

        provider_options = ["anthropic", "google"]
        provider_labels  = ["🟣 Claude (Anthropic)", "🔵 Gemini (Google)"]
        current_idx = provider_options.index(st.session_state.ai_provider) \
                      if st.session_state.ai_provider in provider_options else 0

        selected_label = st.radio(
            "Select provider",
            provider_labels,
            index=current_idx,
            label_visibility="collapsed",
        )
        new_provider = provider_options[provider_labels.index(selected_label)]
        if new_provider != st.session_state.ai_provider:
            st.session_state.ai_provider = new_provider

        # ── API Key inputs ────────────────────────────────────────────────
        st.markdown('<div class="card-title" style="margin-top:0.8rem">🔑 API Keys</div>',
                    unsafe_allow_html=True)

        # Anthropic key
        anthropic_key = st.text_input(
            "Anthropic API Key",
            value=st.session_state.api_key,
            type="password",
            placeholder="sk-ant-...",
            key="api_key_input",
            help="Required when provider = Claude (Anthropic)",
        )
        if anthropic_key != st.session_state.api_key:
            st.session_state.api_key = anthropic_key

        # Google key
        google_key = st.text_input(
            "Google Gemini API Key",
            value=st.session_state.google_api_key,
            type="password",
            placeholder="AIza...",
            key="google_api_key_input",
            help="Required when provider = Gemini (Google)",
        )
        if google_key != st.session_state.google_api_key:
            st.session_state.google_api_key = google_key

        # Status badges
        provider = st.session_state.ai_provider
        active_key = st.session_state.api_key if provider == "anthropic" else st.session_state.google_api_key
        model_name = "claude-opus-4-5" if provider == "anthropic" else "gemini-3-flash-preview"

        if active_key:
            st.markdown(
                f'<span class="badge badge-green">✓ Active: {model_name}</span>',
                unsafe_allow_html=True,
            )
        else:
            key_label = "Anthropic" if provider == "anthropic" else "Google"
            st.markdown(
                f'<span class="badge badge-amber">⚠ {key_label} key required</span>',
                unsafe_allow_html=True,
            )

        # Inactive key warning
        other_provider = "google" if provider == "anthropic" else "anthropic"
        other_key = st.session_state.google_api_key if provider == "anthropic" else st.session_state.api_key
        if other_key:
            other_label = "Gemini" if provider == "anthropic" else "Claude"
            st.markdown(
                f'<div style="font-size:0.72rem;color:#4b5563;margin-top:4px">'
                f'ℹ {other_label} key saved but not active</div>',
                unsafe_allow_html=True,
            )

        st.markdown("---")

        # ── Project settings ──────────────────────────────────────────────
        st.markdown('<div class="card-title">⚙️ Project Settings</div>', unsafe_allow_html=True)
        st.session_state.project_name = st.text_input(
            "Project Name", value=st.session_state.project_name,
            placeholder="e.g. SalesOrderExtension"
        )
        st.session_state.model_prefix = st.text_input(
            "Model/Naming Prefix", value=st.session_state.model_prefix,
            placeholder="e.g. AMMNL_"
        )
        st.session_state.d365_module = st.selectbox(
            "D365 Module",
            ["General", "Sales", "Purchase", "Inventory", "Finance",
             "Production", "HR", "Project", "WMS", "CRM"],
            index=["General", "Sales", "Purchase", "Inventory", "Finance",
                   "Production", "HR", "Project", "WMS", "CRM"]
                  .index(st.session_state.d365_module)
        )

        st.markdown("---")

        # ── Navigation ────────────────────────────────────────────────────
        st.markdown('<div class="card-title">🗺 Navigation</div>', unsafe_allow_html=True)
        nav_items = [
            ("upload",   "📄", "FDD Upload",       st.session_state.fdd_raw_text is None),
            ("analysis", "🔍", "Requirements",     st.session_state.requirements is None),
            ("design",   "🏗️", "Technical Design", st.session_state.technical_design is None),
            ("codegen",  "⚙️", "X++ Code Gen",     st.session_state.xpp_code is None),
            ("review",   "✅", "Review & Export",  st.session_state.xpp_code is None),
        ]
        for page_id, icon, label, locked in nav_items:
            if st.button(f"{icon} {label}", key=f"nav_{page_id}", use_container_width=True,
                         disabled=(locked and page_id not in ("upload",))):
                st.session_state.current_page = page_id
                st.rerun()

        st.markdown("---")

        # ── Pipeline status ───────────────────────────────────────────────
        if st.session_state.fdd_filename:
            st.markdown('<div class="card-title">📊 Pipeline Status</div>', unsafe_allow_html=True)
            items = [
                ("FDD Loaded",       st.session_state.fdd_raw_text is not None),
                ("Requirements",     st.session_state.requirements is not None),
                ("Technical Design", st.session_state.technical_design is not None),
                ("X++ Code",         st.session_state.xpp_code is not None),
                ("Validated",        st.session_state.validation_report is not None),
            ]
            for lbl, done in items:
                icon  = "✅" if done else "⬜"
                color = "#34d399" if done else "#4b5563"
                st.markdown(
                    f'<div style="font-size:0.78rem;color:{color};padding:3px 0">{icon} {lbl}</div>',
                    unsafe_allow_html=True,
                )
