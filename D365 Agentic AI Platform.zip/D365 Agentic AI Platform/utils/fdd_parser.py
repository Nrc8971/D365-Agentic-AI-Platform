"""
FDD File Parser
───────────────
Extracts clean text from PDF, DOCX, and TXT files.
Returns (text, metadata_dict).
"""

import io
from typing import Tuple, Dict, Any


def parse_fdd_file(uploaded_file) -> Tuple[str, Dict[str, Any]]:
    """
    Parse an uploaded FDD file and return (text, metadata).
    
    Supports: .pdf, .docx, .txt
    """
    filename = uploaded_file.name.lower()
    content = uploaded_file.read()

    if filename.endswith(".pdf"):
        return _parse_pdf(content, uploaded_file.name)
    elif filename.endswith(".docx"):
        return _parse_docx(content, uploaded_file.name)
    elif filename.endswith(".txt"):
        return _parse_txt(content, uploaded_file.name)
    else:
        raise ValueError(f"Unsupported file type: {filename}")


def _parse_pdf(content: bytes, filename: str) -> Tuple[str, Dict]:
    try:
        import pdfplumber
        text_parts = []
        num_pages = 0

        with pdfplumber.open(io.BytesIO(content)) as pdf:
            num_pages = len(pdf.pages)
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text_parts.append(page_text)

        text = "\n\n".join(text_parts)

    except ImportError:
        # Fallback to PyPDF2
        try:
            import PyPDF2
            reader = PyPDF2.PdfReader(io.BytesIO(content))
            num_pages = len(reader.pages)
            text_parts = []
            for page in reader.pages:
                t = page.extract_text()
                if t:
                    text_parts.append(t)
            text = "\n\n".join(text_parts)
        except ImportError:
            raise ImportError("Install pdfplumber or PyPDF2: pip install pdfplumber")

    metadata = {
        "file_type": "pdf",
        "pages": num_pages,
        "word_count": len(text.split()),
        "char_count": len(text),
        "filename": filename
    }
    return _clean_text(text), metadata


def _parse_docx(content: bytes, filename: str) -> Tuple[str, Dict]:
    try:
        from docx import Document
        doc = Document(io.BytesIO(content))

        parts = []
        for para in doc.paragraphs:
            if para.text.strip():
                # Keep heading context
                if para.style.name.startswith("Heading"):
                    parts.append(f"\n## {para.text.strip()}\n")
                else:
                    parts.append(para.text.strip())

        # Include tables
        for table in doc.tables:
            for row in table.rows:
                row_text = " | ".join(cell.text.strip() for cell in row.cells if cell.text.strip())
                if row_text:
                    parts.append(row_text)

        text = "\n".join(parts)
        word_count = len(text.split())

        metadata = {
            "file_type": "docx",
            "pages": "N/A",
            "word_count": word_count,
            "char_count": len(text),
            "filename": filename
        }
        return _clean_text(text), metadata

    except ImportError:
        raise ImportError("Install python-docx: pip install python-docx")


def _parse_txt(content: bytes, filename: str) -> Tuple[str, Dict]:
    try:
        text = content.decode("utf-8")
    except UnicodeDecodeError:
        text = content.decode("latin-1")

    metadata = {
        "file_type": "txt",
        "pages": "N/A",
        "word_count": len(text.split()),
        "char_count": len(text),
        "filename": filename
    }
    return _clean_text(text), metadata


def _clean_text(text: str) -> str:
    """Remove excessive whitespace and noise from extracted text."""
    import re
    # Normalize line endings
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    # Remove excessive blank lines (more than 2)
    text = re.sub(r'\n{3,}', '\n\n', text)
    # Remove null bytes and control characters
    text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', text)
    # Normalize spaces
    text = re.sub(r' {3,}', '  ', text)
    return text.strip()
