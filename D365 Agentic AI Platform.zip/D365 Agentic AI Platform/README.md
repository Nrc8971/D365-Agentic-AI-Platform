# ⚡ FDD → X++ Code Generation Platform

> **Functional Design Document → Technical Design → Validated X++ Code for Dynamics 365 F&O**

A focused, accurate, production-grade AI platform that converts FDD documents into 
validated X++ code through a structured 4-stage pipeline.

---

## 🎯 What This Does

```
FDD (PDF/DOCX/TXT)
       ↓
  Stage 1: Requirements Extraction
  └─ Entities, Tables, Business Rules, Validations, Integrations
       ↓
  Stage 2: Technical Design Document
  └─ Architecture, Data Model, Class Design, Process Flows, Full TDD
       ↓
  Stage 3: X++ Code Generation
  └─ Table Extensions, Service Classes, Event Handlers, Forms
       ↓
  Stage 4: 5-Layer Validation + Auto-Retry
  └─ Structure → Naming → DB Safety → X++ Patterns → Completeness
       ↓
  Export: .xpp files, TDD.md, Requirements.json, Full ZIP bundle
```

---

## 🚀 Quick Start

### 1. Clone / Extract

```bash
cd fdd_xpp_platform
```

### 2. Create Virtual Environment

```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Mac/Linux
source venv/bin/activate
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Run the App

```bash
streamlit run app.py
```

The app opens at `http://localhost:8501`

---

## 🔑 API Key Setup

You need an **Anthropic API key**. Get one at: https://console.anthropic.com/keys

Enter it in the sidebar when the app launches. It is never stored to disk.

Optionally create a `.env` file:
```
ANTHROPIC_API_KEY=sk-ant-your-key-here
```

---

## 📋 Usage

### Step 1 — Upload FDD
- Upload your FDD as PDF, DOCX, or TXT
- Configure project settings (name, prefix, module) in the sidebar
- Select which artifacts to generate
- Toggle quality controls

### Step 2 — Requirements Analysis
- AI extracts all entities, tables, fields, business rules, validations, integrations
- Review extracted requirements across tabbed views
- Adjust if needed before proceeding

### Step 3 — Technical Design
- AI generates a complete TDD
- Review data model, class design, process flows
- Download TDD as Markdown

### Step 4 — X++ Code Generation
- AI generates production-grade X++ code for each artifact
- 5-layer validation runs automatically
- Failed artifacts auto-retry with correction prompts
- Per-artifact confidence score (0–100%)

### Step 5 — Review & Export
- Review all artifacts with validation status
- Download individual .xpp files
- Download full ZIP bundle (code + TDD + requirements)

---

## 📁 Project Structure

```
fdd_xpp_platform/
│
├── app.py                          # Streamlit entry point
│
├── ai_engine/
│   ├── base_client.py              # Claude API client with retry logic
│   ├── requirement_analyzer.py     # Stage 1: FDD → Structured requirements
│   ├── design_generator.py         # Stage 2: Requirements → TDD
│   ├── xpp_generator.py            # Stage 3: Design → X++ code
│   └── code_validator.py           # Stage 4: 5-layer validation engine
│
├── ui/
│   ├── layout.py                   # CSS injection, header, sidebar, pipeline tracker
│   └── pages/
│       ├── upload_page.py          # FDD upload + project config
│       ├── analysis_page.py        # Requirements review
│       ├── design_page.py          # TDD review
│       ├── codegen_page.py         # Code generation + validation view
│       └── review_page.py          # Final review + export
│
├── utils/
│   └── fdd_parser.py               # PDF/DOCX/TXT text extractor
│
├── .streamlit/
│   └── config.toml                 # Dark theme + server config
│
├── sample_fdd.txt                  # Sample FDD for testing
└── requirements.txt
```

---

## 🛡 Validation Engine — 5 Layers

| Layer | What It Checks | Severity |
|-------|---------------|----------|
| **Structure** | Class/table declaration, balanced braces | Error (instant fail) |
| **Naming** | Prefix enforcement, camelCase methods | Error |
| **DB Safety** | ttsBegin/ttsCommit, try/catch, ttsAbort | Error |
| **X++ Patterns** | CoC syntax, event handler attrs, no overlay | Error/Warning |
| **Completeness** | No TODOs, XML comments, no empty stubs | Warning |

**Confidence Score formula:**
```
score = 100
score -= 15 per error
score -= 4 per warning  
score += 2 per passing check
score = clamp(score, 0, 100)
```

Auto-retry triggers when: `score < 80 OR errors > 0`

---

## 🤖 AI Model

Uses **Claude claude-opus-4-5** (most accurate) for all generation stages.

Temperature settings:
- Requirements extraction: `0.05` (near-deterministic)
- Technical design: `0.10` (slight creativity for architecture)
- X++ generation: `0.05` (strict, deterministic code)
- Retry/correction: `0.05`

---

## ⚡ X++ Code Principles Enforced

- ✅ Extension-first (never overlay)
- ✅ Chain of Command for method overrides
- ✅ `[ExtensionOf(tableStr(...))]` syntax
- ✅ `ttsBegin` / `ttsCommit` / `ttsAbort` pattern
- ✅ `try { } catch (Exception::Error) { }` wrapping
- ✅ XML doc comments on all public methods
- ✅ Project prefix on all new objects
- ✅ `validateWrite()` / `validateField()` patterns
- ✅ `initValue()` for field defaults
- ✅ `RecordInsertList` for bulk operations
- ✅ Proper EDT usage over base types

---

## 🧪 Testing with Sample FDD

A `sample_fdd.txt` is included. It describes a **Sales Rebate Management** extension
covering: rebate agreements, accrual on sales confirmation, claim processing, AP integration.

Upload it to test the full pipeline.

Expected output:
- ~3 new tables, 2 standard table extensions
- ~4–6 service/helper classes
- ~10–15 business rules extracted
- ~20+ validation checks
- Full TDD document

---

## 🔧 Troubleshooting

**"Could not parse JSON response"**  
→ Retry — occasionally Claude wraps output in unexpected formatting. The retry engine handles this.

**"DB write operations detected but ttsBegin missing"**  
→ Auto-retry enabled — the corrected code will add ttsBegin/ttsCommit automatically.

**PDF text extraction is poor**  
→ Try exporting your PDF from Word as "text-based PDF" rather than scanned. Use DOCX for best results.

**Streamlit upload size limit**  
→ Default is 50MB. Adjust `maxUploadSize` in `.streamlit/config.toml`.

---

## 📦 Export Contents (ZIP bundle)

```
ProjectName_20240101_1200_xpp_bundle.zip
├── xpp/
│   ├── AMMNL_MyTable.xpp
│   ├── MyServiceClass.xpp
│   └── ...
└── docs/
    ├── ProjectName_TDD.md
    ├── ProjectName_requirements.json
    └── ProjectName_validation.md
```

---

## 🗺 Roadmap

- [ ] SSRS report generation
- [ ] DevOps work item creation (Azure DevOps API)
- [ ] Guideline document ingestion (PDF → rules)
- [ ] Multi-FDD comparison / delta analysis
- [ ] Saved project sessions
- [ ] D365 metadata XML import for constraint validation
- [ ] Export as Visual Studio project structure

---

## 📄 License

Proprietary — For internal use only.
