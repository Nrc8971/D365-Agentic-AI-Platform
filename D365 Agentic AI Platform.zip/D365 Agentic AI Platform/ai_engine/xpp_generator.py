"""
X++ Code Generator
───────────────────
Generates production-grade X++ code for D365 F&O.

Principles:
- Extension-first (CoC, EventHandlers, table extensions)
- Proper ttsBegin/ttsCommit patterns
- XML doc comments on all public methods
- Naming convention enforcement
- Never overlays standard D365 objects
"""

import json
from ai_engine.base_client import BaseLLMClient

# ──────────────────────────────────────────────────────────────────────────────
# SYSTEM PROMPT — CORE X++ GENERATION
# ──────────────────────────────────────────────────────────────────────────────
XPP_SYSTEM = """You are a senior Dynamics 365 Finance & Operations X++ developer with 15+ years of experience.

GOLDEN RULES — NEVER VIOLATE:
1. NEVER overlay standard D365 objects — ALWAYS use extensions/CoC/Event Handlers
2. ALL new table names start with project prefix (e.g. AMMNL_MyTable)
3. ALL new field names on standard tables start with project prefix
4. Table extensions use syntax: [ExtensionOf(tableStr(SalesTable))] final class SalesTable_Extension
5. Class extensions (CoC) use: [ExtensionOf(classStr(MyClass))] final class MyClass_Extension
6. Form extensions: [ExtensionOf(formStr(SalesTable))] final class SalesTable_Form_Extension
7. ALWAYS use ttsBegin/ttsCommit when writing to database
8. ALWAYS wrap DB operations in try { } catch (Exception::Error) { ttsAbort; }
9. Use SysQuery::findOrCreate, ::findRecordByQuery patterns
10. Use fieldName(fieldStr(TableName, FieldName)) for dynamic field access
11. Validate with checkFailed() and return false pattern
12. Use #define.CurrentVersion and SysVersionControlMorphX for versioning
13. Event handlers decorated with [DataEventHandler(tableStr(T), DataEventType::Inserting)] etc.
14. RunBase/SysOperation patterns for batch-enabled jobs
15. XML doc comments on ALL public methods: /// <summary> ... </summary>

X++ SYNTAX RULES:
- Variables declared at method start (not inline)
- Use := for assignment in queries
- SalesLine salesLine; (not var)
- while select with where clauses (set-based preferred)
- info(strFmt("...")) for user messages
- error(strFmt("...")); throw error(strFmt("...")) for exceptions
- Use SalesTable::find(salesId) pattern for lookups
- container / List / Map / Set for collections
- RecordInsertList for bulk inserts
- Number of params limit: prefer data contracts
- Label references: "@MyLabel:MyLabelId" 
"""

TABLE_EXT_TEMPLATE = """Generate a complete D365 F&O X++ TABLE EXTENSION for:

Table Design:
{table_json}

Requirements Context:
{req_context}

Project Context:
{project_context}

Generate:
1. Table extension class (if extending standard) OR full table declaration (if new)
2. All specified fields with proper EDTs
3. Index declarations
4. Relation declarations
5. validateWrite() method if validation rules exist
6. validateField() method for field-level validation
7. initValue() for default values
8. modifiedField() if field changes trigger logic

Return ONLY the X++ code. No explanations. Include XML doc comments.
"""

CLASS_TEMPLATE = """Generate complete D365 F&O X++ code for:

Class Design:
{class_json}

Full Requirements:
{req_context}

Project Context:
{project_context}

Generate the COMPLETE, PRODUCTION-READY X++ class with:
1. Full class declaration with proper attributes
2. All member variables declared at class level
3. ALL methods fully implemented (not stubs)
4. Proper error handling in every method that does DB work
5. ttsBegin/ttsCommit around all database write operations
6. XML doc comments on all public methods
7. Parameter validation at method entry
8. Return value validation

Return ONLY the X++ code. No explanations, no markdown fences.
"""

RETRY_TEMPLATE = """The following X++ code failed validation.

VALIDATION ERRORS:
{errors}

VALIDATION WARNINGS:
{warnings}

ORIGINAL CODE:
{original_code}

PROJECT CONTEXT:
{project_context}

Fix ALL errors and warnings. Return the corrected X++ code only.
Ensure:
- All naming convention violations are fixed
- ttsBegin/ttsCommit added where missing
- Error handling added where missing
- Validation methods complete
"""


class XppGenerator(BaseLLMClient):
    """Stage 3 — Design → X++ code. Provider-agnostic."""

    def __init__(self, api_key: str, provider: str = "anthropic"):
        super().__init__(api_key=api_key, provider=provider)

    def generate_table_extension(self, table: dict, req: dict, context: dict) -> str:
        """Generate X++ table extension or new table code."""
        project_ctx = self.build_project_context(context)

        # Build concise requirements context
        req_context = self._build_req_context(req, table.get("name", ""))

        prompt = TABLE_EXT_TEMPLATE.format(
            table_json=json.dumps(table, indent=2),
            req_context=req_context,
            project_context=project_ctx
        )
        return self.call(XPP_SYSTEM, prompt, temperature=0.05, max_tokens=4096)

    def generate_class(self, cls: dict, req: dict, context: dict) -> str:
        """Generate X++ service class or other class type."""
        project_ctx = self.build_project_context(context)
        req_context = self._build_req_context(req, cls.get("name", ""))

        prompt = CLASS_TEMPLATE.format(
            class_json=json.dumps(cls, indent=2),
            req_context=req_context,
            project_context=project_ctx
        )
        return self.call(XPP_SYSTEM, prompt, temperature=0.05, max_tokens=6144)

    def retry_with_corrections(self, original_code: str, validation_result: dict, context: dict) -> str:
        """Retry generation with explicit error corrections."""
        project_ctx = self.build_project_context(context)
        errors = "\n".join(f"- {e}" for e in validation_result.get("errors", []))
        warnings = "\n".join(f"- {w}" for w in validation_result.get("warnings", []))

        prompt = RETRY_TEMPLATE.format(
            errors=errors or "None",
            warnings=warnings or "None",
            original_code=original_code,
            project_context=project_ctx
        )
        return self.call(XPP_SYSTEM, prompt, temperature=0.05, max_tokens=6144)

    @staticmethod
    def _build_req_context(req: dict, artifact_name: str) -> str:
        """Build a focused requirements context for a specific artifact."""
        lines = []

        # Business rules relevant to this artifact
        relevant_rules = [
            r for r in req.get("business_rules", [])
            if artifact_name.lower() in r.get("table", "").lower()
            or artifact_name.lower() in r.get("rule", "").lower()
        ]
        if relevant_rules:
            lines.append("Relevant Business Rules:")
            for r in relevant_rules[:10]:
                lines.append(f"  - [{r.get('priority','medium').upper()}] {r.get('rule','')}")

        # Validations
        relevant_vals = [
            v for v in req.get("validations", [])
            if artifact_name.lower() in v.get("table", "").lower()
            or artifact_name.lower() in v.get("description", "").lower()
        ]
        if relevant_vals:
            lines.append("Validations Required:")
            for v in relevant_vals[:8]:
                lines.append(f"  - [{v.get('type','field')}] {v.get('description','')}")

        # General context
        lines.append(f"\nModule: {req.get('d365_module','General')}")
        lines.append(f"Complexity: {req.get('complexity','Medium')}")

        return "\n".join(lines) if lines else "No specific requirements context."
