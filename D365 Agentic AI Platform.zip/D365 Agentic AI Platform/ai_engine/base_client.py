"""
Dual-Provider LLM Client
────────────────────────
Supports both Anthropic Claude and Google Gemini.
Provider is selected at instantiation based on which key is supplied.
All AI engine modules inherit from BaseLLMClient.

Provider routing:
  provider="anthropic"  →  claude-opus-4-5
  provider="google"     →  gemini-1.5-pro
  provider="auto"       →  uses whichever key is present (Anthropic preferred)
"""

import json
import re
import time
from typing import Optional


# ── Model constants ─────────────────────────────────────────────────────────
ANTHROPIC_MODEL = "claude-opus-4-5"
GOOGLE_MODEL    = "gemini-3-flash-preview"

PROVIDER_ANTHROPIC = "anthropic"
PROVIDER_GOOGLE    = "google"


class BaseLLMClient:
    MAX_TOKENS  = 8192
    MAX_RETRIES = 3
    RETRY_DELAY = 2.0

    def __init__(self, api_key: str, provider: str = PROVIDER_ANTHROPIC):
        """
        Args:
            api_key:  The API key for the chosen provider.
            provider: "anthropic" | "google"
        """
        if not api_key or not api_key.strip():
            raise ValueError(f"{provider.title()} API key is required.")

        self.api_key  = api_key.strip()
        self.provider = provider.lower()

        if self.provider == PROVIDER_ANTHROPIC:
            self._init_anthropic()
        elif self.provider == PROVIDER_GOOGLE:
            self._init_google()
        else:
            raise ValueError(f"Unknown provider '{provider}'. Choose 'anthropic' or 'google'.")

    # ── Provider initialisation ──────────────────────────────────────────────

    def _init_anthropic(self):
        try:
            import anthropic
            self._anthropic_client = anthropic.Anthropic(api_key=self.api_key)
            self._anthropic = anthropic          # keep module ref for error types
        except ImportError:
            raise ImportError("Install anthropic: pip install anthropic")

    def _init_google(self):
        try:
            import google.generativeai as genai
            genai.configure(api_key=self.api_key)
            self._genai        = genai
            self._google_model = genai.GenerativeModel(
                model_name=GOOGLE_MODEL,
                generation_config={"temperature": 0.1, "max_output_tokens": self.MAX_TOKENS},
            )
        except ImportError:
            raise ImportError("Install google-generativeai: pip install google-generativeai")

    # ── Unified call interface ───────────────────────────────────────────────

    def call(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float = 0.1,
        max_tokens: int = None,
        expect_json: bool = False,
    ) -> str:
        """
        Provider-agnostic LLM call with retry logic.
        Returns raw text (or JSON-stripped text if expect_json=True).
        """
        max_tokens = max_tokens or self.MAX_TOKENS

        if self.provider == PROVIDER_ANTHROPIC:
            text = self._call_anthropic(system_prompt, user_prompt, temperature, max_tokens)
        else:
            text = self._call_google(system_prompt, user_prompt, temperature, max_tokens)

        return self._extract_json(text) if expect_json else text

    def call_json(
        self,
        system_prompt: str,
        user_prompt: str,
        schema_hint: str = "",
        temperature: float = 0.05,
    ) -> dict:
        """Call LLM and parse result as a JSON dict."""
        full_system = system_prompt
        if schema_hint:
            full_system += (
                f"\n\nReturn ONLY valid JSON matching this schema:\n{schema_hint}"
                "\n\nNO preamble, NO markdown fences, ONLY the JSON object."
            )
        else:
            full_system += "\n\nReturn ONLY valid JSON. NO preamble, NO markdown fences, NO explanation."

        raw = self.call(full_system, user_prompt, temperature=temperature, expect_json=True)
        try:
            return json.loads(raw)
        except json.JSONDecodeError as e:
            extracted = self._aggressive_json_extract(raw)
            if extracted:
                return extracted
            raise ValueError(
                f"Could not parse JSON from {self.provider} response: {e}\nRaw: {raw[:500]}"
            )

    # ── Anthropic backend ────────────────────────────────────────────────────

    def _call_anthropic(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float,
        max_tokens: int,
    ) -> str:
        for attempt in range(self.MAX_RETRIES):
            try:
                response = self._anthropic_client.messages.create(
                    model=ANTHROPIC_MODEL,
                    max_tokens=max_tokens,
                    temperature=temperature,
                    system=system_prompt,
                    messages=[{"role": "user", "content": user_prompt}],
                )
                return response.content[0].text

            except self._anthropic.RateLimitError:
                if attempt < self.MAX_RETRIES - 1:
                    time.sleep(self.RETRY_DELAY * (attempt + 1))
                    continue
                raise
            except self._anthropic.APIError as e:
                if attempt < self.MAX_RETRIES - 1:
                    time.sleep(self.RETRY_DELAY)
                    continue
                raise RuntimeError(f"Anthropic API error after {self.MAX_RETRIES} attempts: {e}")

        raise RuntimeError("Anthropic: max retries exceeded")

    # ── Google Gemini backend ────────────────────────────────────────────────

    def _call_google(
        self,
        system_prompt: str,
        user_prompt: str,
        temperature: float,
        max_tokens: int,
    ) -> str:
        """
        Gemini does not have a separate system role in the basic API.
        We prepend the system prompt to the user turn with a clear separator.
        """
        combined_prompt = (
            f"SYSTEM INSTRUCTIONS:\n{system_prompt}\n\n"
            f"USER REQUEST:\n{user_prompt}"
        )

        for attempt in range(self.MAX_RETRIES):
            try:
                # Override generation config per-call for temperature/tokens
                model = self._genai.GenerativeModel(
                    model_name=GOOGLE_MODEL,
                    generation_config={
                        "temperature": temperature,
                        "max_output_tokens": max_tokens,
                    },
                )
                response = model.generate_content(combined_prompt)
                return response.text

            except Exception as e:
                err_str = str(e).lower()
                is_rate_limit = "429" in err_str or "quota" in err_str or "rate" in err_str
                if attempt < self.MAX_RETRIES - 1:
                    delay = self.RETRY_DELAY * (attempt + 1) if is_rate_limit else self.RETRY_DELAY
                    time.sleep(delay)
                    continue
                raise RuntimeError(f"Google Gemini error after {self.MAX_RETRIES} attempts: {e}")

        raise RuntimeError("Google Gemini: max retries exceeded")

    # ── Shared utilities ─────────────────────────────────────────────────────

    @staticmethod
    def _extract_json(text: str) -> str:
        """Strip markdown fences from LLM output."""
        text = re.sub(r"```(?:json)?\s*", "", text)
        text = re.sub(r"```\s*$", "", text, flags=re.MULTILINE)
        return text.strip()

    @staticmethod
    def _aggressive_json_extract(text: str) -> Optional[dict]:
        """Last-resort: find the outermost JSON object in messy text."""
        start = text.find("{")
        end   = text.rfind("}")
        if start != -1 and end != -1 and end > start:
            try:
                return json.loads(text[start:end + 1])
            except Exception:
                pass
        return None

    def build_project_context(self, context: dict) -> str:
        """Build a standard project-context block injected into every prompt."""
        return f"""
PROJECT CONTEXT:
- Project Name:     {context.get('project_name', 'MyProject')}
- Naming Prefix:    {context.get('model_prefix', 'PROJ_')}
- D365 Module:      {context.get('d365_module', 'General')}
- Add Error Handling: {context.get('add_error_handling', True)}
- Add XML Comments: {context.get('add_comments', True)}
- Enforce Naming:   {context.get('enforce_naming', True)}
- AI Provider:      {self.provider.title()} ({ANTHROPIC_MODEL if self.provider == PROVIDER_ANTHROPIC else GOOGLE_MODEL})
"""

    @property
    def model_name(self) -> str:
        return ANTHROPIC_MODEL if self.provider == PROVIDER_ANTHROPIC else GOOGLE_MODEL

    @property
    def provider_label(self) -> str:
        return "Claude (Anthropic)" if self.provider == PROVIDER_ANTHROPIC else "Gemini (Google)"
