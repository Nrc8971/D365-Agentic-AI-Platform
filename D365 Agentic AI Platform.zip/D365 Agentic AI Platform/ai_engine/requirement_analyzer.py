"""
Requirement Analyzer
────────────────────
Extracts structured requirements from FDD text using Claude.
Output is a validated JSON structure with entities, rules, tables,
validations, integrations, and metadata.
"""

from ai_engine.base_client import BaseLLMClient

SYSTEM_PROMPT = """You are a senior Microsoft Dynamics 365 F&O functional architect and requirements analyst.

Your task: analyze a Functional Design Document (FDD) and extract ALL requirements in a precise, structured JSON format.

You have deep expertise in:
- Dynamics 365 Finance & Operations data model and standard tables
- X++ development patterns and best practices
- D365 module structure (Sales, Purchase, Inventory, Finance, Production, WMS, HR, Project)
- Extension-first development (never overlay standard objects)
- Business rule extraction and classification
- Gap analysis between FDD requirements and standard D365 functionality

EXTRACTION PRINCIPLES:
1. Extract EVERY entity, table, field, rule explicitly mentioned
2. Infer reasonable D365 tables to extend based on domain context
3. Classify business rules by priority (high/medium/low)
4. Identify ALL validation requirements (field, form, business logic)
5. Flag any ambiguities or missing information
6. Be precise with D365 standard table names (SalesTable, CustTable, etc.)
"""

SCHEMA = """
{
  "executive_summary": "2-3 sentence summary of what this FDD describes",
  "complexity": "Low|Medium|High|Very High",
  "estimated_effort": "e.g. 3-5 developer days",
  "entities": [
    {"name": "EntityName", "description": "what it represents", "d365_equivalent": "standard D365 table if any"}
  ],
  "tables_to_create": [
    {
      "name": "PrefixTableName",
      "purpose": "what it stores",
      "module": "D365 module",
      "table_group": "Main|TransactionHeader|TransactionLine|Group|Parameter|WorksheetHeader|WorksheetLine",
      "fields": [
        {"name": "FieldName", "type": "EDT or base type", "label": "UI label", "mandatory": true|false, "is_key": true|false, "indexed": true|false}
      ]
    }
  ],
  "tables_to_extend": [
    {
      "name": "StandardTableName",
      "reason": "why this table needs extension",
      "fields_to_add": [
        {"name": "PrefixFieldName", "type": "EDT or base type", "label": "UI label", "mandatory": true|false}
      ]
    }
  ],
  "business_rules": [
    {"rule": "exact rule description", "priority": "high|medium|low", "table": "which table this applies to", "implementation_hint": "how to implement in X++"}
  ],
  "validations": [
    {"description": "validation description", "type": "field|form|business_logic|integration", "table": "table name", "trigger": "when this runs"}
  ],
  "integrations": [
    {"system": "system name or D365 module", "description": "what data flows", "type": "API|AIF|DMF|Custom|Internal", "direction": "In|Out|Both"}
  ],
  "form_requirements": [
    {"name": "FormName", "type": "Main|List|Dialog|Workspace", "base_form": "standard form to extend if any", "description": "purpose"}
  ],
  "security_requirements": [
    {"description": "security requirement", "type": "Role|Duty|Privilege|Policy"}
  ],
  "risks": ["risk description"],
  "assumptions": ["assumption made during analysis"],
  "missing_information": ["what's unclear or missing from the FDD"]
}
"""


class RequirementAnalyzer(BaseLLMClient):
    """Stage 1 — FDD → structured requirements. Provider-agnostic."""

    def __init__(self, api_key: str, provider: str = "anthropic"):
        super().__init__(api_key=api_key, provider=provider)

    def analyze(self, fdd_text: str, context: dict) -> dict:
        """
        Analyze FDD text and return structured requirements.
        
        Args:
            fdd_text: Raw text extracted from the FDD document
            context: Project context (name, prefix, module, etc.)
        
        Returns:
            dict matching the SCHEMA above
        """
        project_ctx = self.build_project_context(context)

        user_prompt = f"""{project_ctx}

=== FUNCTIONAL DESIGN DOCUMENT ===
{fdd_text}
=== END OF FDD ===

Analyze this FDD thoroughly. Extract ALL requirements.

Rules for table/field naming:
- New tables and fields MUST use prefix: {context.get('model_prefix', 'PROJ_')}
- Extensions of standard tables: add prefix to new field names only
- Follow D365 naming conventions strictly

Be thorough and precise. Do not miss any entity, rule, or requirement.
"""
        result = self.call_json(SYSTEM_PROMPT, user_prompt, schema_hint=SCHEMA)

        # Post-process: ensure lists exist
        for key in ["entities", "tables_to_create", "tables_to_extend", "business_rules",
                    "validations", "integrations", "form_requirements", "security_requirements",
                    "risks", "assumptions", "missing_information"]:
            if key not in result:
                result[key] = []

        return result
