"""
Design Generator
─────────────────
Produces a complete Technical Design Document from requirements.
Includes: solution architecture, data model, class design, process flows,
full TDD markdown.
"""

from ai_engine.base_client import BaseLLMClient

SYSTEM_PROMPT = """You are a lead D365 F&O solution architect with 15+ years of experience.

Your task: produce a comprehensive Technical Design Document (TDD) from structured requirements.

You have deep expertise in:
- D365 F&O solution architecture patterns
- X++ class hierarchy and design patterns (Service, RunBase, SysOperation, etc.)
- Table extension vs table creation decisions
- EDT (Extended Data Type) design
- Form extension patterns
- Chain of Command (CoC) override patterns
- Event handler patterns (DataEventArgs, FormEventArgs, etc.)
- Performance-safe patterns (set-based operations, proper indexing)
- D365 security model (role/duty/privilege hierarchy)

DESIGN PRINCIPLES:
1. Extension-first: NEVER overlay, always extend
2. Chain of Command for method overrides
3. Service classes for business logic (not code-behind in forms)
4. Proper use of ttsBegin/ttsCommit for all DB writes
5. try/catch/ttsAbort for error handling
6. EDT reuse before creating new base types
7. Indexes on all foreign keys and frequently-queried fields
8. Cache lookup settings based on data volatility
"""

TDD_SCHEMA = """
{
  "architecture_overview": "2-3 paragraph architecture description",
  "design_decisions": [
    {"decision": "what was decided", "rationale": "why", "alternative_considered": "what else was considered"}
  ],
  "components": [
    {"name": "ComponentName", "type": "Table|Service|Form|Enum|EDT|EventHandler|Query", "description": "purpose", "extends": "standard object if extending"}
  ],
  "data_model": {
    "tables": [
      {
        "name": "TableName",
        "action": "create|extend",
        "purpose": "what it stores",
        "table_group": "Main|TransactionHeader|TransactionLine|Group|Parameter",
        "cache_lookup": "NotInTFS|Found|FoundAndEmpty|EntireTable|None",
        "fields": [
          {"name": "FieldName", "type": "EDT or type", "label": "label", "mandatory": false, "indexed": false, "allow_edit": true, "allow_edit_on_create": true}
        ],
        "indexes": [{"name": "IndexName", "fields": ["Field1"], "allow_duplicates": false}],
        "relations": [{"related_table": "TableName", "field": "FieldName", "type": "Normal|ForeignKey"}]
      }
    ],
    "edts": [
      {"name": "EDTName", "extends": "BaseEDT", "label": "UI label", "help_text": "tooltip"}
    ]
  },
  "class_design": [
    {
      "name": "ClassName",
      "type": "Service|RunBase|SysOperationServiceBase|EventHandler|DataContract|Helper",
      "purpose": "what it does",
      "extends": "parent class",
      "implements": ["interface1"],
      "methods": [
        {
          "name": "methodName",
          "modifier": "public|private|protected|static",
          "return_type": "void|boolean|str|int|...",
          "parameters": [{"name": "param", "type": "type"}],
          "description": "what it does",
          "has_tts": false,
          "has_error_handling": true
        }
      ]
    }
  ],
  "process_flows": [
    {"name": "FlowName", "description": "what this flow does", "steps": ["step 1", "step 2"]}
  ],
  "form_design": [
    {
      "name": "FormName",
      "action": "create|extend",
      "base_form": "standard form",
      "data_sources": ["TableName"],
      "description": "purpose and key interactions"
    }
  ],
  "security_design": {
    "privileges": [{"name": "PrivilegeName", "label": "UI label", "objects": [{"name": "TableOrForm", "access": "Read|Update|Create|Delete|Correct"}]}],
    "duties": [{"name": "DutyName", "label": "label", "privileges": ["PrivilegeName"]}]
  },
  "performance_considerations": ["consideration 1", "consideration 2"],
  "testing_strategy": {
    "unit_tests": ["test scenario"],
    "integration_tests": ["test scenario"],
    "uat_scenarios": ["scenario"]
  },
  "deployment_notes": ["note 1"],
  "full_tdd_markdown": "# Technical Design Document\\n..."
}
"""

TDD_TEMPLATE = """# Technical Design Document
## {project_name}

**Version:** 1.0  
**Module:** {module}  
**Prefix:** {prefix}  
**Status:** Draft

---

## 1. Executive Summary
{exec_summary}

---

## 2. Solution Architecture
{architecture}

---

## 3. Data Model
{data_model_section}

---

## 4. Class Design
{class_section}

---

## 5. Process Flows
{flows_section}

---

## 6. Form Design
{form_section}

---

## 7. Security Design
{security_section}

---

## 8. Performance Considerations
{performance_section}

---

## 9. Testing Strategy
{testing_section}

---

## 10. Deployment Notes
{deployment_section}
"""


class DesignGenerator(BaseLLMClient):
    """Stage 2 — Requirements → Technical Design Document. Provider-agnostic."""

    def __init__(self, api_key: str, provider: str = "anthropic"):
        super().__init__(api_key=api_key, provider=provider)

    def generate(self, fdd_text: str, requirements: dict, context: dict) -> dict:
        """
        Generate Technical Design Document from requirements.
        """
        import json
        project_ctx = self.build_project_context(context)

        user_prompt = f"""{project_ctx}

=== STRUCTURED REQUIREMENTS ===
{json.dumps(requirements, indent=2)}
=== END REQUIREMENTS ===

=== ORIGINAL FDD (for additional context) ===
{fdd_text[:3000]}
=== END FDD EXCERPT ===

Design a complete technical solution for these requirements. 

Critical requirements:
1. Use prefix '{context.get('model_prefix','PROJ_')}' for ALL new objects
2. Extension-first: extend standard D365 objects, never overlay
3. Service class pattern for all business logic
4. Proper indexes on all FK fields and query fields
5. Security model must cover all new objects
6. Full TDD markdown must be complete and professional

The full_tdd_markdown field must be a complete, well-formatted markdown document.
"""
        result = self.call_json(SYSTEM_PROMPT, user_prompt, schema_hint=TDD_SCHEMA, temperature=0.1)

        # Build full TDD markdown if not provided
        if not result.get("full_tdd_markdown") or len(result.get("full_tdd_markdown", "")) < 200:
            result["full_tdd_markdown"] = self._build_tdd_markdown(result, requirements, context)

        return result

    def _build_tdd_markdown(self, td: dict, req: dict, context: dict) -> str:
        """Build a full TDD markdown document from the structured design."""
        lines = []
        proj = context.get('project_name', 'Project')
        prefix = context.get('model_prefix', 'PROJ_')
        module = context.get('d365_module', 'General')

        lines.append(f"# Technical Design Document — {proj}\n")
        lines.append(f"**D365 Module:** {module} | **Prefix:** `{prefix}` | **Version:** 1.0\n")
        lines.append("---\n")

        lines.append("## 1. Executive Summary\n")
        lines.append(req.get("executive_summary", "N/A") + "\n\n")
        lines.append(f"**Complexity:** {req.get('complexity','Medium')} | **Effort:** {req.get('estimated_effort','TBD')}\n")

        lines.append("\n## 2. Architecture Overview\n")
        lines.append(td.get("architecture_overview", "N/A") + "\n")

        lines.append("\n## 3. Design Decisions\n")
        for dd in td.get("design_decisions", []):
            lines.append(f"### {dd.get('decision','?')}\n")
            lines.append(f"**Rationale:** {dd.get('rationale','')}\n")
            if dd.get("alternative_considered"):
                lines.append(f"**Alternative considered:** {dd.get('alternative_considered','')}\n")

        lines.append("\n## 4. Data Model\n")
        for tbl in td.get("data_model", {}).get("tables", []):
            lines.append(f"### {tbl.get('name','')} ({tbl.get('action','create').upper()})\n")
            lines.append(f"**Purpose:** {tbl.get('purpose','')}\n")
            lines.append(f"**Table Group:** `{tbl.get('table_group','Main')}` | **Cache:** `{tbl.get('cache_lookup','NotInTFS')}`\n\n")
            if tbl.get("fields"):
                lines.append("| Field | Type | Label | Mandatory | Indexed |\n")
                lines.append("|-------|------|-------|-----------|--------|\n")
                for f in tbl["fields"]:
                    lines.append(f"| `{f.get('name','')}` | `{f.get('type','')}` | {f.get('label','')} | {'✓' if f.get('mandatory') else ''} | {'✓' if f.get('indexed') else ''} |\n")
            if tbl.get("indexes"):
                lines.append("\n**Indexes:**\n")
                for idx in tbl["indexes"]:
                    lines.append(f"- `{idx.get('name','')}` on `{', '.join(idx.get('fields',[]))}` — Unique: {'No' if idx.get('allow_duplicates') else 'Yes'}\n")

        lines.append("\n## 5. Class Design\n")
        for cls in td.get("class_design", []):
            lines.append(f"### {cls.get('name','')} ({cls.get('type','')})\n")
            lines.append(f"**Purpose:** {cls.get('purpose','')}\n")
            lines.append(f"**Extends:** `{cls.get('extends','Object')}`\n\n")
            if cls.get("methods"):
                lines.append("| Method | Modifier | Returns | Description |\n")
                lines.append("|--------|----------|---------|-------------|\n")
                for m in cls["methods"]:
                    lines.append(f"| `{m.get('name','')}` | `{m.get('modifier','public')}` | `{m.get('return_type','void')}` | {m.get('description','')} |\n")

        lines.append("\n## 6. Process Flows\n")
        for flow in td.get("process_flows", []):
            lines.append(f"### {flow.get('name','')}\n")
            lines.append(f"{flow.get('description','')}\n\n")
            for i, step in enumerate(flow.get("steps", []), 1):
                lines.append(f"{i}. {step}\n")

        lines.append("\n## 7. Security Design\n")
        sec = td.get("security_design", {})
        if sec.get("duties"):
            lines.append("**Duties:**\n")
            for d in sec["duties"]:
                lines.append(f"- `{d.get('name','')}` — {d.get('label','')}\n")

        lines.append("\n## 8. Performance Considerations\n")
        for p in td.get("performance_considerations", []):
            lines.append(f"- {p}\n")

        lines.append("\n## 9. Testing Strategy\n")
        ts = td.get("testing_strategy", {})
        if ts.get("unit_tests"):
            lines.append("**Unit Tests:**\n")
            for t in ts["unit_tests"]:
                lines.append(f"- {t}\n")
        if ts.get("uat_scenarios"):
            lines.append("\n**UAT Scenarios:**\n")
            for t in ts["uat_scenarios"]:
                lines.append(f"- {t}\n")

        lines.append("\n## 10. Deployment Notes\n")
        for note in td.get("deployment_notes", []):
            lines.append(f"- {note}\n")

        return "".join(lines)
