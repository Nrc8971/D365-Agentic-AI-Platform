"""
Code Validator — 5-Layer X++ Validation Engine
────────────────────────────────────────────────
Layer 1: Structure    — code is non-empty, has class/table declaration
Layer 2: Naming       — prefix enforcement, camelCase methods
Layer 3: DB Safety    — ttsBegin/ttsCommit, try/catch presence
Layer 4: Patterns     — CoC syntax, event handler syntax, no overlays
Layer 5: Completeness — no TODO/stub methods, has XML comments
"""

import re
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import List, Tuple, Dict, Any


class CheckStatus(Enum):
    PASS = "pass"
    WARNING = "warning"
    FAIL = "fail"


@dataclass
class ValidationCheck:
    name: str
    status: CheckStatus
    message: str
    severity: str = "info"  # info | warning | error
    auto_fixable: bool = False

    def to_dict(self):
        d = asdict(self)
        d["status"] = self.status.value
        return d


@dataclass
class ValidationResult:
    valid: bool
    confidence_score: int
    checks: List[ValidationCheck]
    errors: List[str]
    warnings: List[str]
    suggestions: List[str]
    retryable: bool = True

    def to_dict(self):
        return {
            "valid": self.valid,
            "confidence_score": self.confidence_score,
            "checks": [c.to_dict() for c in self.checks],
            "errors": self.errors,
            "warnings": self.warnings,
            "suggestions": self.suggestions,
            "retryable": self.retryable,
        }


class CodeValidator:
    """
    Multi-layer X++ code validator.
    Returns a ValidationResult with confidence score 0-100.
    """

    def validate(self, code: str, context: dict, artifact_type: str = "class") -> dict:
        checks = []
        errors = []
        warnings = []
        suggestions = []

        prefix = context.get("model_prefix", "PROJ_")

        # ── Layer 1: Structure ──────────────────────────────────────────────
        struct_ok, struct_msg = self._check_structure(code, artifact_type)
        checks.append(ValidationCheck(
            "Structure Check",
            CheckStatus.PASS if struct_ok else CheckStatus.FAIL,
            struct_msg,
            severity="error" if not struct_ok else "info",
        ))
        if not struct_ok:
            errors.append(struct_msg)
            # Structure fail = instant low score
            return ValidationResult(
                valid=False, confidence_score=5, checks=checks,
                errors=errors, warnings=warnings, suggestions=["Fix code structure"],
                retryable=True
            ).to_dict()

        # ── Layer 2: Naming Conventions ────────────────────────────────────
        naming_issues = self._check_naming(code, prefix, artifact_type)
        if naming_issues:
            for issue in naming_issues:
                errors.append(issue)
            checks.append(ValidationCheck(
                "Naming Conventions",
                CheckStatus.FAIL,
                f"{len(naming_issues)} naming issue(s) found",
                severity="error",
                auto_fixable=True
            ))
        else:
            checks.append(ValidationCheck("Naming Conventions", CheckStatus.PASS, "All naming conventions OK", severity="info"))

        # ── Layer 3: DB Safety ─────────────────────────────────────────────
        db_issues = self._check_db_safety(code)
        if db_issues["errors"]:
            for e in db_issues["errors"]:
                errors.append(e)
            checks.append(ValidationCheck(
                "DB Safety (tts/catch)",
                CheckStatus.FAIL,
                f"{len(db_issues['errors'])} DB safety issue(s)",
                severity="error",
                auto_fixable=True
            ))
        elif db_issues["warnings"]:
            for w in db_issues["warnings"]:
                warnings.append(w)
            checks.append(ValidationCheck(
                "DB Safety (tts/catch)",
                CheckStatus.WARNING,
                f"{len(db_issues['warnings'])} DB safety warning(s)",
                severity="warning",
                auto_fixable=True
            ))
        else:
            checks.append(ValidationCheck("DB Safety (tts/catch)", CheckStatus.PASS, "DB safety patterns OK"))

        # ── Layer 4: X++ Patterns ──────────────────────────────────────────
        pattern_issues = self._check_xpp_patterns(code, artifact_type)
        if pattern_issues["errors"]:
            for e in pattern_issues["errors"]:
                errors.append(e)
            checks.append(ValidationCheck(
                "X++ Patterns",
                CheckStatus.FAIL,
                f"{len(pattern_issues['errors'])} pattern error(s)",
                severity="error"
            ))
        elif pattern_issues["warnings"]:
            for w in pattern_issues["warnings"]:
                warnings.append(w)
            checks.append(ValidationCheck(
                "X++ Patterns",
                CheckStatus.WARNING,
                f"{len(pattern_issues['warnings'])} pattern warning(s)",
                severity="warning"
            ))
        else:
            checks.append(ValidationCheck("X++ Patterns", CheckStatus.PASS, "X++ patterns correct"))

        # ── Layer 5: Completeness ──────────────────────────────────────────
        completeness_issues = self._check_completeness(code, context)
        if completeness_issues:
            for w in completeness_issues:
                warnings.append(w)
            checks.append(ValidationCheck(
                "Completeness",
                CheckStatus.WARNING,
                f"{len(completeness_issues)} completeness warning(s)",
                severity="warning"
            ))
        else:
            checks.append(ValidationCheck("Completeness", CheckStatus.PASS, "Code appears complete"))

        # ── Score Calculation ──────────────────────────────────────────────
        score = self._calculate_score(checks, errors, warnings)

        # Suggestions
        if naming_issues:
            suggestions.append(f"Add prefix '{prefix}' to new object names")
        if db_issues.get("errors"):
            suggestions.append("Wrap all DB write operations in ttsBegin/ttsCommit")
        if completeness_issues:
            suggestions.append("Replace TODO stubs with full implementations")

        return ValidationResult(
            valid=len(errors) == 0,
            confidence_score=score,
            checks=checks,
            errors=errors,
            warnings=warnings,
            suggestions=suggestions,
            retryable=len(errors) > 0 and score > 10
        ).to_dict()

    # ── Layer implementations ──────────────────────────────────────────────

    def _check_structure(self, code: str, artifact_type: str) -> Tuple[bool, str]:
        if not code or len(code.strip()) < 30:
            return False, "Code is empty or too short"

        code_lower = code.lower()

        if artifact_type == "table":
            if not any(kw in code_lower for kw in ["table ", "class ", "[extensionof"]):
                return False, "No table or class declaration found"
        else:
            if "class " not in code_lower and "[extensionof" not in code_lower:
                return False, "No class declaration found"

        # Check for balanced braces
        open_braces = code.count("{")
        close_braces = code.count("}")
        if abs(open_braces - close_braces) > 2:
            return False, f"Unbalanced braces: {open_braces} open vs {close_braces} close"

        return True, "Code structure valid"

    def _check_naming(self, code: str, prefix: str, artifact_type: str) -> List[str]:
        issues = []
        prefix_upper = prefix.upper().rstrip("_")

        # Find class declarations that should have prefix
        class_matches = re.findall(r'\bclass\s+(\w+)', code, re.IGNORECASE)
        for name in class_matches:
            # Skip extension classes and standard names
            if any(skip in name.lower() for skip in ["_extension", "_form_"]):
                continue
            # Check if it's a new class (not extending standard)
            if not any(standard in name for standard in ["Sales", "Cust", "Vend", "Invent", "Ledger", "Tax"]):
                # New class should have prefix
                if not name.upper().startswith(prefix_upper):
                    issues.append(f"Class '{name}' should start with prefix '{prefix}'")

        # Check method naming (should be camelCase)
        method_matches = re.findall(r'\b(?:public|private|protected|static)\s+\w+\s+(\w+)\s*\(', code)
        for method in method_matches:
            if method[0].isupper() and method not in ["New", "Main", "Construct"]:
                issues.append(f"Method '{method}' should be camelCase (starts with lowercase)")

        return issues[:5]  # Cap at 5 to avoid noise

    def _check_db_safety(self, code: str) -> Dict[str, List[str]]:
        errors = []
        warnings = []
        code_lower = code.lower()

        # Detect DB write operations
        has_insert = bool(re.search(r'\b(\.insert\(\)|\.update\(\)|\.delete\(\)|\.doInsert\(\)|\.doUpdate\(\))\b', code, re.IGNORECASE))
        has_write_select = bool(re.search(r'\bupdate_recordset\b|\bdelete_from\b|\binsert_recordset\b', code, re.IGNORECASE))
        has_db_write = has_insert or has_write_select

        has_tts_begin = bool(re.search(r'\bttsBegin\b', code, re.IGNORECASE))
        has_tts_commit = bool(re.search(r'\bttsCommit\b', code, re.IGNORECASE))
        has_try = bool(re.search(r'\btry\b\s*\{', code, re.IGNORECASE))
        has_catch = bool(re.search(r'\bcatch\b', code, re.IGNORECASE))
        has_tts_abort = bool(re.search(r'\bttsAbort\b', code, re.IGNORECASE))

        if has_db_write:
            if not has_tts_begin:
                errors.append("DB write operations detected but ttsBegin is missing")
            if not has_tts_commit:
                errors.append("DB write operations detected but ttsCommit is missing")
            if has_tts_begin and not has_try:
                warnings.append("ttsBegin without try/catch block — consider adding error handling")
            if has_try and not has_tts_abort:
                warnings.append("try block without ttsAbort in catch — DB transaction may not roll back")

        # Check select operations
        has_select = bool(re.search(r'\bselect\b|\bfind\s*\(', code, re.IGNORECASE))
        if has_select and not has_try:
            warnings.append("Database read operations without exception handling")

        return {"errors": errors, "warnings": warnings}

    def _check_xpp_patterns(self, code: str, artifact_type: str) -> Dict[str, List[str]]:
        errors = []
        warnings = []
        code_lower = code.lower()

        # No overlay check — look for direct modification of standard object methods without CoC
        if "public void " in code and "extensionof" not in code_lower:
            # Check if there are method overrides without CoC
            if "override" in code_lower and "extensionof" not in code_lower:
                errors.append("Method override without Chain of Command — use [ExtensionOf] attribute")

        # Extension syntax check
        has_extension = "[extensionof" in code_lower
        if has_extension:
            # Verify final class keyword
            if "final class" not in code_lower:
                errors.append("Extension class must be declared as 'final class'")

        # Check for inline variable declarations (X++ requires top-of-method)
        inline_decl = re.findall(r'(?:for|while|if)\s*\(.*\b(int|str|boolean|real)\b', code, re.IGNORECASE)
        if inline_decl:
            warnings.append("Possible inline variable declarations — X++ requires declaration at method start")

        # Check event handler attribute syntax
        if "dataeventhandler" in code_lower or "formdataeventhandler" in code_lower:
            if not re.search(r'\[Data(?:Event)?Handler\s*\(', code, re.IGNORECASE):
                errors.append("Event handler attribute syntax appears incorrect")

        # Warn about hardcoded strings that should be labels
        hardcoded_msgs = re.findall(r'(?:info|error|warning)\s*\(\s*"([^"]{20,})"', code)
        if hardcoded_msgs:
            warnings.append(f"Found {len(hardcoded_msgs)} hardcoded string(s) — consider using D365 labels (@LabelFile:LabelId)")

        return {"errors": errors, "warnings": warnings}

    def _check_completeness(self, code: str, context: dict) -> List[str]:
        warnings = []

        # Stub detection
        todo_count = len(re.findall(r'\bTODO\b|\bSTUB\b|\bNOT IMPLEMENTED\b', code, re.IGNORECASE))
        if todo_count:
            warnings.append(f"{todo_count} TODO/STUB placeholder(s) — replace with real implementation")

        # XML comment check
        if "/// <summary>" not in code and context.get("add_comments", True):
            warnings.append("No XML doc comments found — add /// <summary> to public methods")

        # Empty method bodies
        empty_methods = re.findall(r'\{[\s]*\}', code)
        if len(empty_methods) > 2:
            warnings.append(f"{len(empty_methods)} potentially empty method bodies detected")

        return warnings

    @staticmethod
    def _calculate_score(checks: list, errors: list, warnings: list) -> int:
        score = 100
        for err in errors:
            score -= 15
        for warn in warnings:
            score -= 4
        # Bonus for clean checks
        passing = sum(1 for c in checks if c.status == CheckStatus.PASS)
        score += passing * 2
        return max(0, min(100, score))
